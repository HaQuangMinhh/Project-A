const { OAuth2Client } = require('google-auth-library');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const session = require('express-session');
const bcrypt = require('bcrypt');
const { randomBytes } = require('crypto');

// Thay thế trực tiếp các giá trị
const GOOGLE_CLIENT_ID = '1092266308342-8hrg3jv9sqtjppe3v902agm5nv80oil3.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';
const SESSION_SECRET = 'your-session-secret'; // Đổi thành khóa bí mật riêng
const client = new OAuth2Client(GOOGLE_CLIENT_ID);

// LOGIN
app.post('/login', async (req, res) => {
    const { googleToken, username, password } = req.body;

    if (googleToken) {
        try {
            const ticket = await client.verifyIdToken({
                idToken: googleToken,
                audience: GOOGLE_CLIENT_ID,
            });
            const payload = ticket.getPayload();
            const googleEmail = payload.email;

            connection.query('SELECT * FROM users WHERE username = ?', [googleEmail], (err, results) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
                }

                const nextSessionId = randomBytes(16).toString('hex');
                if (results.length > 0) {
                    const { id: userId, role } = results[0];
                    SESSIONS[nextSessionId] = { userId, username: googleEmail, role };

                    res.cookie('sessionId', nextSessionId, {
                        secure: false,
                        httpOnly: true,
                        sameSite: 'lax',
                        maxAge: 2 * 24 * 60 * 60 * 1000,
                    });

                    return res.json({ success: true, userId, username: googleEmail, role });
                } else {
                    const newUser = { username: googleEmail, password: null, role: 0 };
                    connection.query('INSERT INTO users SET ?', newUser, (err, result) => {
                        if (err) {
                            console.error('Error inserting user:', err);
                            return res.status(500).json({ success: false, message: 'Internal Server Error' });
                        }

                        const userId = result.insertId;
                        SESSIONS[nextSessionId] = { userId, username: googleEmail, role: 0 };

                        res.cookie('sessionId', nextSessionId, {
                            secure: false,
                            httpOnly: true,
                            sameSite: 'lax',
                            maxAge: 2 * 24 * 60 * 60 * 1000,
                        });

                        return res.json({ success: true, userId, username: googleEmail, role: 0 });
                    });
                }
            });
        } catch (error) {
            console.error('Google OAuth Error:', error);
            return res.status(401).json({ success: false, message: 'Invalid Google token' });
        }
    } else if (username && password) {
        connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
            if (err) {
                console.error('Error fetching user:', err);
                return res.status(500).json({ success: false, message: 'Internal Server Error' });
            }

            if (results.length === 0) {
                return res.json({ success: false, message: 'User does not exist. Please try again...' });
            }

            bcrypt.compare(password, results[0].password, (err, isMatch) => {
                if (err) {
                    console.error('Error comparing passwords:', err);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
                }

                if (isMatch) {
                    const nextSessionId = randomBytes(16).toString('hex');
                    const { id: userId, role } = results[0];
                    SESSIONS[nextSessionId] = { userId, username, role };

                    res.cookie('sessionId', nextSessionId, {
                        secure: false,
                        httpOnly: true,
                        sameSite: 'lax',
                        maxAge: 2 * 24 * 60 * 60 * 1000,
                    });

                    return res.json({ success: true, userId, username, role });
                } else {
                    return res.json({ success: false, message: 'Invalid password. Please try again...' });
                }
            });
        });
    } else {
        return res.status(400).json({ success: false, message: 'Missing login information' });
    }
});

// Passport Config
passport.use(new GoogleStrategy({
    clientID: GOOGLE_CLIENT_ID,
    clientSecret: GOOGLE_CLIENT_SECRET,
    callbackURL: '/auth/google/callback',
}, (accessToken, refreshToken, profile, done) => {
    return done(null, profile);
}));

passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((user, done) => {
    done(null, user);
});

app.use(session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
}));

app.use(passport.initialize());
app.use(passport.session());

app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/' }),
    (req, res) => {
        res.redirect('/customer1.html');
    }
);
// -------------------------------------------------------------------------------------------------
// <!-- Google Sign-In Script -->
// <script src="https://accounts.google.com/gsi/client" async defer></script>

// <!-- Google Sign-In Integration -->
// <div id="google-login" class="google-login">
//     <h2>Or Login with Google</h2>
//     <div id="g_id_onload"
//          data-client_id="YOUR_GOOGLE_CLIENT_ID"
//          data-context="signin"
//          data-ux_mode="popup"
//          data-login_uri="http://localhost:3000/auth/google/callback"
//          data-auto_prompt="false">
//     </div>
//     <div class="g_id_signin" 
//          data-type="standard" 
//          data-shape="rectangular" 
//          data-theme="outline" 
//          data-text="sign_in_with" 
//          data-size="large" 
//          data-logo_alignment="left">
//     </div>
// </div>
