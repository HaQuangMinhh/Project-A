CREATE DATABASE next_door_restaurant;
USE next_door_restaurant;


CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) NOT NULL DEFAULT 0
);
ALTER TABLE users
ADD created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE users
ADD role INT NOT NULL DEFAULT 0;

-- Updated PhoneNumber, address , email  
ALTER TABLE users 
ADD COLUMN phoneNumber VARCHAR(20),
ADD COLUMN address VARCHAR(255),
ADD COLUMN email VARCHAR(255);

-- update + sắp xếp lại users 
ALTER TABLE users 
ADD COLUMN firstName VARCHAR(50) AFTER username, 
ADD COLUMN lastName VARCHAR(50) AFTER firstName, 
ADD COLUMN bio TEXT AFTER email;


select * from users;


CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255)
);


CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
ALTER TABLE `invoices`
DROP FOREIGN KEY `invoices_ibfk_1`;

ALTER TABLE `invoices`
ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`user_id`) 
REFERENCES `users`(`id`) 
ON DELETE CASCADE;

CREATE TABLE invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
ALTER TABLE `invoice_items`
DROP FOREIGN KEY `invoice_items_ibfk_1`;

ALTER TABLE `invoice_items`
ADD CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) 
REFERENCES `invoices`(`id`) 
ON DELETE CASCADE;


INSERT INTO products (name, description, price, image_url) VALUES
('Turkish Toast', 'Turkish toast with our own homemade sauce', 99000, 'product_1.png'),
('Egg Avocado Salad', 'Avocado salad with eggs creates a sweet taste.', 79000, 'product_2.png'),
('Pink Guava Tomato Salad', 'Vegetable salad with pink guava, tomatoes and eggs.', 70000, 'product_3.png'),
('Chicken Hamburgers', 'Hamburger with crispy fried chicken.', 109000, 'product_4.png'),
('Taco', 'Crispy cake filled with vegetables.', 139000, 'product_5.png'),
('Gorgeous Orange Color', 'Salmon with sweet and sour orange sauce', 1490000, 'product_6.png');

INSERT INTO users (username, password, role) 
VALUES ('admin', '$2b$12$t9bYN3T9lr1TKyu.9/W2MOtsD.0XNyLTe5bpChyPd5uQrMMurZnie', 1);

CREATE TABLE contact_feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    feedback VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM contact_feedbacks;

-- MH updated 2/10 
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    datetime DATETIME NOT NULL,
    quantity INT NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    message TEXT
);
-- ---------------------------------------------

select * from invoices;
select * from products;
select * from users;
select * from invoice_items;
select * from bookings;
select * from contact_feedbacks order by created_at asc;


INSERT INTO products (name, description, price, image_url) VALUES
('Bouillabaisse', 'Marinated with spices and seafood juice', 1250000 , 'product8.png'),
('Ratatouille', 'Vegetables like tomatoes, eggplants, pumpkins, carrots and onions' , 3900000 , 'product9.png'),
('Foie Gras' , 'Bread or with sweet and sour fruit juice', 4800000 , 'product10.png'),
('Macaron' , 'Egg whites, powdered sugar, granulated sugar', 1420000, 'product11.png' ), 
( 'Escargot' , 'Herbs, basil, onions, chives, garlic', 2530000, 'product12.png' ),
('Crepe', 'Ice cream, chocolate sauce or caramel sauce', 1890000, 'product13.png'),
( 'French Beef' , 'Flour, warm milk, salt, butter, eggs, sugar, chocolate', 3600000, 'product14.png'),
('Moules Marine', 'Wine with garlic, some spicy spices', 2500000, 'product15.png' ),
('Steak Tartare', 'Minced or chopped beef or sometimes horse meat', 1760000, 'product16.png'),
('Baguette' , 'Flour, salt, yeast and water', 3200000 , 'product17.png' ),
('Boeuf Seafood' , 'Shrimp, crab, clams, oysters and salmon' , 1500000 , 'product18.png');


