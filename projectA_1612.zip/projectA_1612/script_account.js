document.addEventListener('DOMContentLoaded', () => {
            fetch('/users')      // Lấy danh sách user từ API và hiển thị lên bảng
                .then(response => response.json())
                .then(users => {
                    const userList = document.getElementById('user-list');
                    users.forEach(user => {
                    const userRow = document.createElement('tr');
                    userRow.innerHTML = `
                        <td>${user.id}</td>
                        <td>${user.username}</td>
                        <td>${user.role === 1 ? 'Admin' : 'User'}</td>
                        <td>
                            <button class="delete-user-button" data-user-id="${user.id}">Delete</button>
                            ${user.role === 1 ? '' : `<button class="upgrade-button" data-user-id="${user.id}">Upgrade to Admin</button>`}
                            ${user.role === 0 ? '' : `<button class="downgrade-button" data-user-id="${user.id}">Downgrade to User</button>`}
                            <button class="view-details-button" data-user-id="${user.id}" data-username="${user.username}" data-role="${user.role}">View Details</button>
                        </td>
                    `;
                    userList.appendChild(userRow);
                });
                    // condition ? valueIfTrue : valueIfFalse


                    // Thêm event listener cho nút "Upgrade to Admin"
                    document.querySelectorAll('.upgrade-button').forEach(button => {
                        button.addEventListener('click', function() {
                            const userId = this.getAttribute('data-user-id');
                            upgradeToAdmin(userId);
                        });
                    });
                    // Thêm event listener cho nút "Downgrade to User"
                    document.querySelectorAll('.downgrade-button').forEach(button => {
                        button.addEventListener('click', function() {
                            const userId = this.getAttribute('data-user-id');
                            downgradeToUser(userId);
                        });
                    });

                    // Thêm event listener cho nút "Delete"
                    document.querySelectorAll('.delete-user-button').forEach(button => {
                        button.addEventListener('click', function() {
                            const userId = this.getAttribute('data-user-id');
                            deleteUser(userId);
                        });
                    });

                    // Thêm event listener cho nút "View Details"
                    document.querySelectorAll('.view-details-button').forEach(button => {
                        button.addEventListener('click', function () {
                            const userId = this.getAttribute('data-user-id');

                            // Fetch thông tin user từ API
                            fetch(`/user/${userId}`)
                              .then(response => response.json())
                              .then(userDetails => {
                                // Điền thông tin vào các trường
                                document.getElementById('user-username').value = userDetails.username || '';
                                document.getElementById('user-first-name').value = userDetails.firstName || '';
                                document.getElementById('user-last-name').value = userDetails.lastName || '';
                                document.getElementById('user-email').value = userDetails.email || '';
                                document.getElementById('user-phone').value = userDetails.phoneNumber || '';
                                document.getElementById('user-password').value = userDetails.password || '';
                                document.getElementById('user-bio').value = userDetails.bio || '';

                                // Hiển thị modal
                                document.getElementById('details-modal').style.display = 'block';
                              })
                              .catch(error => console.error('Error fetching user details:', error));
                        });
                    });

                    // Đóng modal khi nhấn nút "Close"
                    document.getElementById('close-modal-btn').addEventListener('click', closeModal);
                    
                    function closeModal() {
                      document.getElementById('details-modal').style.display = 'none';
                    }

                    // Hàm kiểm tra mật khẩu theo chính sách
                    function validatePassword(password) {
                        if (password.length === 0) {
                            return 'Vui lòng nhập mật khẩu của bạn';
                        }
                        if (password.length < 8) {
                            return 'Mật khẩu phải có ít nhất 8 kí tự';
                        }
                        if (/\s/.test(password)) {
                            return 'Mật khẩu không được chứa khoảng trắng';
                        }
                        if (!/[A-Z]/.test(password)) {
                            return 'Mật khẩu phải có ít nhất một kí tự in hoa';
                        }
                        if (!/[a-z]/.test(password)) {
                            return 'Mật khẩu phải có ít nhất một kí tự là chữ thường';
                        }
                        if (!/[0-9]/.test(password)) {
                            return 'Mật khẩu phải có ít nhất một kí tự là số';
                        }
                        if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
                            return 'Mật khẩu phải có ít nhất một kí tự đặc biệt';
                        }
                        return null;  // Trả về null nếu mật khẩu hợp lệ
                    }

                    // Lưu thay đổi khi nhấn nút "Save"
                    document.getElementById('save-changes').addEventListener('click', function () {
                        
                        const updatedDetails = {
                            username: document.getElementById('user-username').value,
                            firstName: document.getElementById('user-first-name').value,
                            lastName: document.getElementById('user-last-name').value,
                            email: document.getElementById('user-email').value,
                            phoneNumber: document.getElementById('user-phone').value,
                            password: document.getElementById('user-password').value,
                            bio: document.getElementById('user-bio').value,

                        };

                        const newPassword = document.getElementById('user-password').value;
                        
                        // Kiểm tra mật khẩu theo chính sách
                        const passwordError = validatePassword(newPassword);
                        if (passwordError) {
                            alert(passwordError);  // Hiển thị lỗi nếu mật khẩu không hợp lệ
                            return;  // Dừng lại nếu mật khẩu không hợp lệ
                        }

                        // Chỉ cập nhật mật khẩu nếu có thay đổi
                        if (newPassword) {
                            updatedDetails.password = newPassword;  // Gửi mật khẩu mới nếu có
                        }

                        // Gửi thông tin cập nhật lên server
                        fetch(`/user/update`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(updatedDetails),
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    alert('User details updated successfully!');
                                    closeModal();
                                    location.reload();  // Tải lại trang sau khi thành công

                                    // Chuyển hướng lại trang hiện tại
                                    window.location.href = window.location.href;  // Điều này sẽ làm mới lại trang mà không cần tải lại từ đầu

                                } else {
                                    alert('Failed to update user details: ' + data.message);
                                }
                            })
                            .catch(error => console.error('Error updating user details:', error));
                    });

                })
                .catch(error => console.error('Error fetching users:', error));
        });

        // Hàm upgrade user thành Admin
        function upgradeToAdmin(userId) {
            fetch(`/upgrade-user/${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ role: 1 }) // Cập nhật role thành Admin
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error upgrading user');
                }
                alert('User upgraded to Admin successfully!');
                location.reload();
            })
            .catch(error => {
                console.error('Error upgrading user:', error);
                alert('Error upgrading user. Please try again.');
            });
        }
        // Hàm downgrade admin thành User
        function downgradeToUser(userId) {
            fetch(`/downgrade-user/${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ role: 0 }) // Cập nhật role thành User
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error downgrading user');
                }
                alert('Admin downgraded to User successfully!');
                location.reload();
            })
            .catch(error => {
                console.error('Error downgrading user:', error);
                alert('Error downgrading user. Please try again.');
            });
        }

        // Hàm xóa user
        function deleteUser(userId) {
            fetch(`/delete-user/${userId}`, {
                method: 'DELETE'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error deleting user');
                }
                alert('User deleted successfully!');
                location.reload();
            })
            .catch(error => {
                console.error('Error deleting user:', error);
                alert('Error deleting user. Please try again.');
            });
        }


        // Hàm view details
        function createAndShowModal(userId) {
            fetch(`/user/${userId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to fetch user details');
                    }
                    return response.json();
                })
                .then(userDetails => {
                    const modalContent = `
                        <div class="modal">
                            <div class="modal-content">
                                <span class="close-button">&times;</span>
                                <h2>User Details</h2>
                                <p><strong>Username:</strong> ${userDetails.username}</p>
                                <p><strong>First Name:</strong> ${userDetails.firstName || 'N/A'}</p>
                                <p><strong>Last Name:</strong> ${userDetails.lastName || 'N/A'}</p>
                                <p><strong>Email:</strong> ${userDetails.email || 'N/A'}</p>
                                <p><strong>Phone Number:</strong> ${userDetails.phoneNumber || 'N/A'}</p>
                                <p><strong>Bio:</strong> ${userDetails.bio || 'N/A'}</p>
                            </div>
                        </div>
                    `;

                    const modalWrapper = document.createElement('div');
                    modalWrapper.innerHTML = modalContent;
                    document.body.appendChild(modalWrapper);

                    const closeButton = modalWrapper.querySelector('.close-button');
                    closeButton.addEventListener('click', () => {
                        document.body.removeChild(modalWrapper);
                    });

                    modalWrapper.addEventListener('click', event => {
                        if (event.target === modalWrapper) {
                            document.body.removeChild(modalWrapper);
                        }
                    });
                })
                .catch(error => {
                    console.error('Error fetching user details:', error);
                    alert('Error fetching user details. Please try again.');
                });
        }

        



        // Hàm logout
        function logout() {
            fetch('/logout', { method: 'POST' })
                .then(() => {
                    window.location.href = 'login.html';
                })
                .catch(error => console.error('Error logging out:', error));
        }