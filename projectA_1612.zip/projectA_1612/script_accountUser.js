// ---------------------------------------- Get infor từ database lên --------------------------
document.addEventListener('DOMContentLoaded', () => {
        fetch('/accountUserInfo')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch user info');
                }
                return response.json();
            })
            .then(userInfo => {
                document.getElementById('username-readonly').value = userInfo.username;
                document.getElementById('username').value = userInfo.username; // Editable
                document.getElementById('first-name-readonly').value = userInfo.firstName || '';
                document.getElementById('last-name-readonly').value = userInfo.lastName || '';
                document.getElementById('email-readonly').value = userInfo.email || '';
                document.getElementById('phone-readonly').value = userInfo.phoneNumber || '';
                document.getElementById('bio-readonly').value = userInfo.bio || ''; // Bio added

                // Update Personal Details (Editable)
                document.getElementById('username').value = userInfo.username || '';
                document.getElementById('first-name').value = userInfo.firstName || '';
                document.getElementById('last-name').value = userInfo.lastName || '';
                document.getElementById('email').value = userInfo.email || '';
                document.getElementById('phone').value = userInfo.phoneNumber || '';
                document.getElementById('bio').value = userInfo.bio || ''; // Editable bio
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Could not load user info.');
            });
    });


// --------------------------------Click SAVE -------------------------------------------------
// Function to validate password policy
const passwordValidator = (password) => {
    if (password.length === 0) {
        return 'Vui lòng nhập mật khẩu của bạn';
    }
    if (password.length < 8) {
        return 'Mật khẩu phải có ít nhất 8 kí tự';
    }
    if (/\s/.test(password)) {
        return 'Mật khẩu không được chứa khoảng trắng';
    }
    if (!/[A-Z]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự in hoa';
    }
    if (!/[a-z]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự là chữ thường';
    }
    if (!/[0-9]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự là số';
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự đặc biệt';
    }
    return '';
};

document.getElementById('save-button').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent form submission from refreshing the page

    const username = document.getElementById('username').value.trim() || document.getElementById('username-readonly').value.trim(); ;
    const firstName = document.getElementById('first-name').value.trim();
    const lastName = document.getElementById('last-name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phoneNumber = document.getElementById('phone').value.trim();
    const password = document.getElementById('password').value.trim();
    const bio = document.getElementById('bio').value.trim();

    // Kiểm tra thông tin nhập vào
    if (!firstName || !lastName || !email || !phoneNumber || !password || !bio) {
        alert('Please fill in all fields.');
        return;
    }

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    const phonePattern = /^[+]?[0-9]{10,15}$/;
    if (!phonePattern.test(phoneNumber)) {
        alert('Please enter a valid phone number.');
        return;
    }

    
    // Kiểm tra policy mật khẩu
    const passwordError = passwordValidator(password);
    if (passwordError) {
        alert(passwordError); // Hiển thị thông báo lỗi
        return;
    }

    if (bio.length < 10) {
        alert('Bio must be at least 10 characters long.');
        return;
    }

    // // Hiển thị thông tin đã cập nhật trên giao diện
    // document.getElementById('display-username').innerText = username;
    // document.getElementById('display-full-name').innerText = `${firstName} ${lastName}`;
    // document.getElementById('display-email').innerText = email;
    // document.getElementById('display-phone').innerText = phoneNumber;
    // document.getElementById('display-password').innerText = '********'; // Không hiển thị mật khẩu rõ
    // document.getElementById('display-bio').innerText = bio;

    
    // Gửi thông tin về server
    const updatedData = {
        username,
        firstName,
        lastName,
        email,
        phoneNumber,
        password,
        bio,
    };

    console.log(updatedData); // Xem thông tin trước khi gửi fetch

    fetch('/update-user-details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData),
    })
        .then((response) => {
            console.log('Server response:', response);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((data) => {
            console.log('Server response data:', data); // Log dữ liệu trả về từ server
            if (data.success) {
                alert('Details updated successfully.');
                document.getElementById('display-username').innerText = username;
                document.getElementById('display-full-name').innerText = `${firstName} ${lastName}`;
                document.getElementById('display-email').innerText = email;
                document.getElementById('display-phone').innerText = phoneNumber;
                document.getElementById('display-bio').innerText = bio;

                // Reload lại trang
                window.location.reload();
            } else {
                alert(`Error: ${data.message}`);
            }
        })
        .catch((error) => {
            console.error('Fetch error:', error);
            alert('An error occurred while updating your details.');
        });

});





// ----------------------------------------  Logout ---------------------------------------------
// Hàm logout
        function logout() {
            fetch('/logout', { method: 'POST' })
                .then(() => {
                    window.location.href = 'login.html';
                })
                .catch(error => console.error('Error logging out:', error));
        }
