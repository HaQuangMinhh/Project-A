

function scrollToContact() {
    document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
}


// ====================================================Booking

// Booking done Updated 9/10 
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    let valid = true;

    // Clear any previous error messages
    const errorMessages = this.querySelectorAll('.error-message');
    errorMessages.forEach(function(msg) {
        msg.style.display = 'none';
    });

    // Validate each required field
    const fields = this.querySelectorAll('input[required], textarea[required]');
    fields.forEach(function(field) {
        if (!field.value.trim()) {
            // Show the error message next to the field
            const errorMessage = field.nextElementSibling;
            errorMessage.textContent = "Please fill out this field";
            errorMessage.style.display = 'block';
            valid = false;
        }
    });

    // If all fields are valid, submit the form (or trigger any further actions)
    if (valid) {
        alert("Form submitted successfully!"); // Replace with actual form submission logic
        this.submit(); // Uncomment if you are using a real form submission
    }
});

// =====================================================================Gửi form và dữ liệu tới server 
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn không cho form gửi theo cách truyền thống

    // Lấy dữ liệu từ form
    const formData = new FormData(this);

    fetch('submit_booking.php', {
        method: 'POST',
        body: formData, // Gửi dữ liệu dưới dạng FormData
    })
    .then(response => response.json())
    .then(data => {
        // Hiển thị thông báo thành công hoặc lỗi
        alert(data.message);
    })
    // .catch(error => {
    //     console.error('Error:', error);
    //     alert('Có lỗi xảy ra khi gửi đặt bàn.');  Còn lỗi ở chỗ này vì nó gửi infor đi mà mình vẫn chưa nhận được
    // });
});
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn không cho form gửi theo cách truyền thống

    // Lấy dữ liệu từ form
    const formData = new FormData(this);

    fetch('submit_booking.php', {
        method: 'POST',
        body: formData, // Gửi dữ liệu dưới dạng FormData
    })
    .then(response => {
        console.log('Response status:', response.status); // Kiểm tra mã trạng thái
        return response.json(); // Tiếp tục xử lý JSON
    })
    .then(data => {
        // Hiển thị thông báo thành công hoặc lỗi
        alert(data.message);
    })
    // .catch(error => {
    //     console.error('Error:', error);
    //     alert('Có lỗi xảy ra khi gửi đặt bàn.');
    // });
});



//===================================================================





