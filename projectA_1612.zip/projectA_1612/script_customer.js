document.addEventListener('DOMContentLoaded', () => {
    let userRole = null;

    // Lấy thông tin tài khoản và role của người dùng
    fetch('/account')
        .then(response => response.json())
        .then(data => {
            // Hiển thị tên người dùng
            document.getElementById('username').textContent = escapeHtml(data.username);
            
            // Lưu role của user
            userRole = data.role;

            // Sau khi có role, tải danh sách sản phẩm
            loadProducts(userRole);
        })
        .catch(error => console.error('Error fetching account data:', error));

    // Thêm sự kiện cho nút Logout
    document.getElementById('logout-button').addEventListener('click', (event) => {
        event.preventDefault();
        logout();
    });

    // Thêm sự kiện cho nút Tìm kiếm
    document.getElementById('search-button').addEventListener('click', searchDishes);


    // Thêm sự kiện nhấn Enter vào ô tìm kiếm
    document.getElementById('search-input').addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            searchDishes();
        }
    });

    // Thêm sự kiện cho nút Tạo hóa đơn
    document.getElementById('create-invoice-button').addEventListener('click', createInvoice);

    // Hiển thị thông báo nếu có message
    const params = new URLSearchParams(window.location.search);
    const message = params.get('message');
    if (message) {
        alert(message);
    }
});

// Hàm escape HTML
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') {
        return unsafe;
    }
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Hàm tải danh sách sản phẩm dựa trên role của user
function loadProducts(role) {
    fetch('/products1')
        .then(response => response.json())
        .then(products => {
            const productList = document.getElementById('product-list');
            productList.innerHTML = ''; // Xóa các sản phẩm cũ nếu có

            products.forEach(product => {
                const productItem = document.createElement('div');
                productItem.className = 'product-item';
                productItem.dataset.id = product.id;
                productItem.dataset.name = product.name;
                productItem.dataset.price = product.price;

                const img = document.createElement('img');
                img.src = `assets/${product.image_url}`;
                img.alt = escapeHtml(product.name);

                const title = document.createElement('h3');
                title.textContent = escapeHtml(product.name);

                const description = document.createElement('p');
                description.textContent = escapeHtml(product.description);

                const priceDiv = document.createElement('div');
                priceDiv.className = 'price';
                priceDiv.textContent = `${Math.round(product.price).toLocaleString()} VNĐ`;

                const button = document.createElement('button');
                
                if (role === 1) {
                    console.log('Admin role detected');
                    button.textContent = 'Update';
                    button.className = 'update-button';
                    button.addEventListener('click', () => updateItem(product));
                } else if (role === 0) {
                    button.textContent = 'Select';
                    button.className = 'select-button';
                    button.addEventListener('click', () => selectItem(button));
                }

                productItem.appendChild(img);
                productItem.appendChild(title);
                productItem.appendChild(description);
                productItem.appendChild(priceDiv);
                productItem.appendChild(button);

                productList.appendChild(productItem);
            });
        })
        .catch(error => console.error('Error fetching products:', error));


    // Add event for button Logout

    document.getElementById('logout-button').addEventListener('click', (event) => {
        event.preventDefault();
        logout();
    });

    // Add event for button Search
    document.getElementById('search-button').addEventListener('click', searchDishes);

    // Add event for button Enter int search 
    document.getElementById('search-input').addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            searchDishes();
        }
    });

    // Add event for button Create Invoice
    document.getElementById('create-invoice-button').addEventListener('click', createInvoice);




};

const invoiceData = {
    items: []
};


function selectItem(button) {
    const productItem = button.parentElement;
    const id = productItem.getAttribute('data-id');
    const name = productItem.getAttribute('data-name');
    const price = parseFloat(productItem.getAttribute('data-price'));

    const existingItem = invoiceData.items.find(item => item.id === id);

    if (existingItem) {
        existingItem.quantity += 1;
        existingItem.price = price * existingItem.quantity;
    } else {
        invoiceData.items.push({ id, name: escapeHtml(name), price, quantity: 1 });
    }

    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    updateInvoiceDisplay();
}

// Hàm mở form cập nhật
function updateItem(product) {
    console.log('Update item clicked');
    // Hiển thị form cập nhật
    const updateFormContainer = document.getElementById('update-form-container');
    updateFormContainer.style.display = 'flex'; // Mở form

    // Điền thông tin sản phẩm vào form
    document.getElementById('update-id').value = product.id;
    document.getElementById('update-name').value = product.name;
    document.getElementById('update-description').value = product.description;
    document.getElementById('update-price').value = product.price;
    document.getElementById('update-image').value = product.image_url;
}

// Hàm đóng form cập nhật
function closeUpdateForm() {
    document.getElementById('update-form-container').style.display = 'none';
}

 // Hiển thị input file khi nhấn nút "Change Image"
    document.getElementById('change-image-button').addEventListener('click', function() {
        document.getElementById('image-file').click();
    });

    // Cập nhật tên file khi người dùng chọn ảnh
    document.getElementById('image-file').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            // Lấy tên tệp từ file
            const fileName = file.name;
            // Hiển thị tên tệp vào input text
            document.getElementById('update-image').value = fileName;
        }
    });

// Xử lý sự kiện submit form cập nhật
document.getElementById('update-form').addEventListener('submit', (event) => {
    event.preventDefault();

    // Lấy dữ liệu từ form
    const updatedProduct = {
        id: document.getElementById('update-id').value,
        name: document.getElementById('update-name').value.trim(), // Loại bỏ khoảng trắng
        description: document.getElementById('update-description').value.trim(), // Loại bỏ khoảng trắng
        price: parseFloat(document.getElementById('update-price').value), // Chuyển thành số
        image_url: document.getElementById('update-image').value.trim() // Loại bỏ khoảng trắng
    };

    // Kiểm tra xem các trường có dữ liệu không
    if (!updatedProduct.name || !updatedProduct.description || !updatedProduct.price || !updatedProduct.image_url) {
        alert('Please fill all fields.');
        return;
    }

    // Gửi yêu cầu PUT để cập nhật sản phẩm
    fetch(`/products/${updatedProduct.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedProduct) // Chuyển thành chuỗi JSON
    })
        .then(response => {
            if (response.ok) {
                alert('Product updated successfully!');
                loadProducts(1); // Tải lại danh sách sản phẩm
                closeUpdateForm();
            } else {
                return response.json().then(error => { throw new Error(error.error); });
            }
        })
        .catch(error => {
            console.error('Error updating product:', error);
            alert('Failed to update product: ' + error.message);
        });
});




function updateInvoiceDisplay() {
    const invoiceList = document.getElementById('invoice-list');
    const invoiceTotalAmount = document.getElementById('invoice-total-amount');
    invoiceList.innerHTML = '';

    let total = 0;
    invoiceData.items.forEach((item, index) => {
        const invoiceItem = document.createElement('div');
        invoiceItem.className = 'invoice-item';

        const itemName = document.createElement('span');
        itemName.textContent = `${escapeHtml(item.name)} (x${item.quantity})`;
        const itemPrice = document.createElement('span');
        itemPrice.textContent = `${(item.price).toLocaleString()} VNĐ`;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.className = 'remove-item';
        removeButton.addEventListener('click', () => removeItem(index));

        invoiceItem.appendChild(itemName);
        invoiceItem.appendChild(itemPrice);
        invoiceItem.appendChild(removeButton);
        invoiceList.appendChild(invoiceItem);

        total += item.price;
    });

    invoiceTotalAmount.textContent = total.toLocaleString() + ' VNĐ';
}

function removeItem(index) {
    invoiceData.items.splice(index, 1);
    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    updateInvoiceDisplay();
}





function createInvoice() {
    const invoice_list = JSON.parse(localStorage.getItem('invoiceData'));

     // Kiểm tra dữ liệu invoice_list và dừng lại nếu không hợp lệ
    if (!invoice_list || !Array.isArray(invoice_list.items) || invoice_list.items.length === 0) {
        alert('Cannot create invoice. No items selected!');
        return; // Dừng hàm tại đây
    }

// Updated 1910 ===============================
     // Tạo hóa đơn mới
    const newInvoice = {
        id: Date.now(), // Tạo ID duy nhất cho hóa đơn
        items: invoice_list.items, // Lưu danh sách món ăn
        totalAmount: invoice_list.items.reduce((total, item) => total + item.price, 0), // Tính tổng số tiền
        createdAt: new Date().toISOString() // Thời gian tạo hóa đơn theo định dạng ISO
    };

    // Thêm hóa đơn mới vào danh sách hóa đơn cũ
    const oldInvoices = JSON.parse(localStorage.getItem('invoices')) || [];
    oldInvoices.push(newInvoice);
    localStorage.setItem('invoices', JSON.stringify(oldInvoices));


    fetch('/create-invoice', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(invoice_list)
    })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Error creating invoice');
            }
        })

        .then(data => {

            if (data && data.invoiceId) {
                alert('Invoice created successfully! Invoice ID: ' + escapeHtml(data.invoiceId));
                updateInvoiceDisplay();
                // Xóa dữ liệu invoiceData khỏi localStorage
                localStorage.removeItem('invoiceData');

                // Tải lại trang
                window.location.reload();
                
            } else {
                throw new Error('Invalid response from server');
            }

        })
        .catch(error => {
            console.error('Error creating invoice:', error);
            alert('An error occurred while creating the invoice.');
        });
}


function searchDishes() {
    const query = document.getElementById('search-input').value.toLowerCase();
    const productList = document.getElementById('product-list');
    const productItems = productList.getElementsByClassName('product-item');

    Array.from(productItems).forEach(item => {
        const name = item.querySelector('h3').textContent.toLowerCase();
        item.style.display = name.includes(query) ? 'block' : 'none';
    });
}

function logout() {
    fetch('/logout')
        .then(() => {
            window.location.href = 'login.html';
        })
        .catch(error => console.error('Error during logout:', error));
}

