

function scrollToContact() {
    document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
}


// Modal for Enlarged Image 

const images1 = [
    { src: 'assets/event1.webp', title: 'For young enthusiasts who are captivated by beautiful scenery and eager to immerse themselves in the vibrant atmosphere of the city'}, 
    { src: 'assets/event2.webp', title: 'Enjoy a delightful and intimate dining experience'}, 
    { src: 'assets/event3.webp', title: 'All dishes will be meticulously prepared at the preparation station'}, 
    { src: 'assets/event4.webp', title: 'The dishes will be beautifully presented, ensuring an appealing visual experience'}, 
    { src: 'assets/event5.webp', title: 'A sense of atmosphere designed for older couples to enjoy a moment of tranquility together.'}, 
    { src: 'assets/event6.webp', title: 'A tranquil corner of the restaurant provides a perfect setting for guests to engage in pleasant conversations together'}, 
    { src: 'assets/event7.webp', title: 'The restaurant places great emphasis on creating a family-friendly atmosphere, fostering a warm ambiance during the year-end celebrations'}, 
    { src: 'assets/event8.webp', title: 'Groups of friends can enjoy a panoramic view of the entire city skyline from the restaurant.'}, 
    { src: 'assets/event9.webp', title: 'Friends can gather and enjoy a few drinks while reminiscing about the moments they shared'}, 
    // { src: 'assets/event10.webp', title: 'Hãnh kẹo3'}, 
    { src: 'assets/event11.webp', title: 'The atmosphere at the main bar is incredibly lively, where guests gather around to engage in conversation with one another.'}, 
    
];

const images2 = [
    
    {src : 'assets/event22.webp', title: 'Couples will find a serene space beside the pool where they can enjoy a meal together'},
    // {src : 'assets/event23.webp', title: 'Bay vào không gian2'},
    {src : 'assets/event24.webp', title: 'There will be renowned singers and musicians performing.'},
    {src : 'assets/event25.webp', title: 'You will be treated to delightful songs throughout your time at Next Door Restaurant'},
    // {src : 'assets/event26.webp', title: 'Bay vào không gian'},
    // {src : 'assets/event27.webp', title: 'Bay vào không gian'},
    // {src : 'assets/event28.webp', title: 'Bay vào không gian'},
    // {src : 'assets/event29.webp', title: 'Bay vào không gian'},
    // {src : 'assets/event30.webp', title: 'Bay vào không gian'},


];

const images3 = [
    
    {src : 'assets/valen1.webp', title: 'The entire restaurant is harmoniously decorated, enhancing the ambiance and making the space truly stand out'},
    // {src : 'assets/valen2.webp', title: 'Bay vào không gian2'},
    {src : 'assets/valen3.webp', title: 'Before important events, our restaurant will be meticulously decorated to ensure that guests feel as though they are part of a truly elegant celebration'},
    {src : 'assets/valen4.webp', title: 'When visiting Next Door Restaurant, you can savor a glass of wine paired with exquisite dishes, creating a delightful flavor experience'},
    {src : 'assets/valen5.webp', title: 'The interior will be elegantly decorated to accommodate around six people for dining or celebrating with family'},
    {src : 'assets/valen6.webp', title: 'From above, you will appreciate the restaurants elegance with its sophisticated design style'},
    // {src : 'assets/valen7.webp', title: 'Bay vào không gian'},
    // {src : 'assets/valen8.webp', title: 'Bay vào không gian'},
    // {src : 'assets/valen9.webp', title: 'Bay vào không gian'},
    // {src : 'assets/valen10.webp', title: 'Bay vào không gian'},
];

let currentIndex1 = 0;
let currentIndex2 = 0 ; 
let currentIndex3 = 0;



function openModal(modalId) {
    document.getElementById(modalId).style.display = "flex"; // Hiển thị modal
    if (modalId === "imageModal1") {
        changeImage(images1[currentIndex1], modalId);
    } else if (modalId === "imageModal2") {
        changeImage(images2[currentIndex2], modalId);
    } else if (modalId === "imageModal3") {
        changeImage(images3[currentIndex3], modalId);
    }
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none"; // Ẩn modal
}



function changeImage(imageObj, modalId) {
    const imgElement = document.querySelector(`#${modalId} .full-image`);
    const titleElement = document.querySelector(`#${modalId} .image-title`);

    imgElement.classList.add('fade'); // Bắt đầu hiệu ứng mờ

    setTimeout(() => {
        imgElement.src = imageObj.src; // Thay đổi nguồn hình ảnh
        imgElement.classList.remove('fade'); // Kết thúc hiệu ứng mờ
    }, 500); // Thời gian phù hợp với CSS transition

    titleElement.innerText = imageObj.title; // Cập nhật tiêu đề
}





function navigate(direction, modalId) {
    if (modalId === "imageModal1") {
        if (direction === 'next') {
            currentIndex1 = (currentIndex1 + 1) % images1.length;
        } else {
            currentIndex1 = (currentIndex1 - 1 + images1.length) % images1.length;
        }
        changeImage(images1[currentIndex1], modalId);

    } else if (modalId === "imageModal2") {
        if (direction === 'next') {
            currentIndex2 = (currentIndex2 + 1) % images2.length;
        } else {
            currentIndex2 = (currentIndex2 - 1 + images2.length) % images2.length;
        }
        changeImage(images2[currentIndex2], modalId);
    } else if (modalId === "imageModal3") {
        if (direction === 'next') {
            currentIndex3 = (currentIndex3 + 1) % images3.length;
        } else {
            currentIndex3 = (currentIndex3 - 1 + images3.length) % images3.length;
        }
        changeImage(images3[currentIndex3], modalId);
    }
}

// Thêm sự kiện cho các nút tiếp theo và trước
document.getElementById("nextButton1").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('next', 'imageModal1');
});

document.getElementById("prevButton1").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('prev', 'imageModal1');
});

document.getElementById("nextButton2").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('next', 'imageModal2');
});

document.getElementById("prevButton2").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('prev', 'imageModal2');
});

document.getElementById("nextButton3").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('next', 'imageModal3');
});

document.getElementById("prevButton3").addEventListener("click", function(event) {
    event.stopPropagation(); // Ngăn click đóng modal
    navigate('prev', 'imageModal3');
});








