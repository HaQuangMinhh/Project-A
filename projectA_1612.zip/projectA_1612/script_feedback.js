// Hàm định dạng DateTime
        function formatDateTime(datetimeString) {
            const options = {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false // 24-hour format
            };
            const date = new Date(datetimeString);
            return date.toLocaleString('en-GB', options); // định dạng theo chuẩn tiếng Anh - Anh
        }

        // Lấy dữ liệu phản hồi từ server
        fetch('/feedbacks')
            .then(response => response.json())
            .then(data => {
                const tableBody = document.querySelector('#feedback-table tbody');
                data.forEach(feedback => {
                    const row = `
                        <tr>
                            <td>${feedback.feedback}</td>
                            <td>${formatDateTime(feedback.created_at)}</td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                });
            })
            .catch(error => console.error('Error fetching feedbacks:', error));


// Nút scroll xuống cuối 
function scrollToContact() {
    document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
}



