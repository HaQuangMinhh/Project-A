
        // // document.addEventListener('DOMContentLoaded', () => {
        // //     const invoiceData = JSON.parse(localStorage.getItem('invoiceData'));

        // //     if (invoiceData && invoiceData.items.length > 0) {
        // //         const invoiceList = document.getElementById('invoice-list');

        // //         let totalAmount = 0; // Khởi tạo tổng số tiền cho hóa đơn
                

        // //         invoiceData.items.forEach(item => {
        // //             const invoiceItem = document.createElement('div');
        // //             invoiceItem.className = 'invoice-item';
        // //             invoiceItem.innerHTML = `
        // //                 <span>${item.name}</span>
        // //                 <span>${item.price.toLocaleString()} VNĐ</span>
        // //             `;
        // //             invoiceList.appendChild(invoiceItem);
        // //             totalAmount += item.price;
        // //         });

        // //         document.getElementById('invoice-total-amount').textContent = totalAmount.toLocaleString() + ' VNĐ';
        // //     } else {
        // //         document.getElementById('invoice-list').innerHTML = '<p>No items in this invoice.</p>';
        // //     }

        //     // Hiển thị hóa đơn cũ
        //     const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
        //     invoices.forEach((oldInvoice, index) => {
        //         const oldInvoiceContainer = document.createElement('div');
        //         oldInvoiceContainer.className = 'old-invoice-container';
        //         oldInvoiceContainer.innerHTML = `
        //             <h3>Invoice ${index + 1}</h3>
        //             <div class="old-invoice-items"></div>
        //             <div class="old-invoice-total">Total: ${oldInvoice.totalAmount.toLocaleString()} VNĐ</div>
        //         `;
                
        //         const itemsContainer = oldInvoiceContainer.querySelector('.old-invoice-items');
        //         oldInvoice.items.forEach(item => {
        //             const oldInvoiceItem = document.createElement('div');
        //             oldInvoiceItem.className = 'old-invoice-item';
        //             oldInvoiceItem.innerHTML = `
        //                 <span>${item.name}</span>
        //                 <span>${item.price.toLocaleString()} VNĐ</span>
        //             `;
        //             itemsContainer.appendChild(oldInvoiceItem);
        //         });
                
        //         oldInvoicesList.appendChild(oldInvoiceContainer);
        //     });
        // });
    

            document.addEventListener('DOMContentLoaded', () => {
            // Hiển thị hóa đơn hiện tại
            const invoiceData = JSON.parse(localStorage.getItem('invoiceData'));
            const invoiceList = document.getElementById('invoice-list');
            const oldInvoicesList = document.getElementById('old-invoices-list');
            let totalAmount = 0;

            // Hiển thị hóa đơn hiện tại
            if (invoiceData && invoiceData.items.length > 0) {
                invoiceData.items.forEach(item => {
                    const invoiceItem = document.createElement('div');
                    invoiceItem.className = 'invoice-item';
                    invoiceItem.innerHTML = `
                        <span>${item.name}</span>
                        <span>${item.price.toLocaleString()} VNĐ</span>
                    `;
                    invoiceList.appendChild(invoiceItem);
                    totalAmount += item.price;
                });
                document.getElementById('invoice-total-amount').textContent = totalAmount.toLocaleString() + ' VNĐ';
            } else {
                invoiceList.innerHTML = '<p>No items in this invoice.</p>';
            }

            // Hiển thị Hóa Đơn Cũ
            const oldInvoices = JSON.parse(localStorage.getItem('invoices')) || [];
            oldInvoices.forEach(oldInvoice => {
            const oldInvoiceContainer = document.createElement('div');
            oldInvoiceContainer.className = 'invoice-wrapper'; // Sử dụng lớp CSS mới

            // Tiêu đề bao gồm ID hóa đơn và thời gian tạo
            const createdAt = new Date(oldInvoice.createdAt).toLocaleString();
            const invoiceHeading = document.createElement('h3');
            invoiceHeading.textContent = `ID: ${oldInvoice.id} - Created at: ${createdAt}`;
            oldInvoiceContainer.appendChild(invoiceHeading);

            const itemsContainer = document.createElement('div');
            itemsContainer.className = 'item-list'; // Danh sách món ăn
            oldInvoice.items.forEach(item => {
                    const oldInvoiceItem = document.createElement('div');
                    oldInvoiceItem.className = 'old-invoice-item';
                    oldInvoiceItem.innerHTML = `
                        <span>${item.name}</span>
                        <span style="float: right;">${item.price.toLocaleString()} VNĐ</span> <!-- Số tiền ở cuối dòng -->
                    `;
                    itemsContainer.appendChild(oldInvoiceItem);

                    // Thêm khoảng cách giữa các món ăn
                    oldInvoiceItem.style.marginBottom = '10px'; // Thay đổi giá trị này để điều chỉnh khoảng cách
            });

                oldInvoiceContainer.appendChild(itemsContainer);
                const totalAmountDiv = document.createElement('div');
                totalAmountDiv.className = 'total-amount';
                totalAmountDiv.innerHTML = `Total: <span style="float: right;">${oldInvoice.totalAmount.toLocaleString()} VNĐ</span>`; // Số tiền tổng ở cuối dòng
                oldInvoiceContainer.appendChild(totalAmountDiv);

                oldInvoicesList.prepend(oldInvoiceContainer); // Sử dụng prepend để thêm hóa đơn mới ở đầu
            });
        });



        


        
         



    
// =====================================================================================================
        function logout() {
            fetch('/logout')
                .then(() => {
                    window.location.href = 'login.html'; 
                })
                .catch(error => console.error('Error during logout:', error));
        }
  
        const params = new URLSearchParams(window.location.search);
        const message = params.get('message');
        if (message) {
          alert(message);
        }