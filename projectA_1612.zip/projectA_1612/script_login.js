
        // Print alert if there's a message
const params = new URLSearchParams(window.location.search);
const message = params.get('message');
if (message) {
    alert(message);
}

// Variable to track username availability
let isUsernameAvailable = false;

// Function to check username availability
const checkUsernameAvailability = (username) => {
    fetch(`/check-username?username=${encodeURIComponent(username)}`)
        .then(response => response.json())
        .then(data => {
            const availabilityMessage = document.getElementById('username-availability');
            if (data.available) {
                availabilityMessage.textContent = 'Username is available.';
                availabilityMessage.style.color = 'green';
                isUsernameAvailable = true; // Username is available
            } else {
                availabilityMessage.textContent = 'Username already exists.';
                availabilityMessage.style.color = 'red';
                isUsernameAvailable = false; // Username is not available
            }
        })
        .catch(error => {
            console.error('Error checking username:', error);
        });
};

// Event listener for username input
document.getElementById('new-username').addEventListener('input', function() {
    const username = this.value;
    if (username.length > 0) {
        checkUsernameAvailability(username);
    } else {
        document.getElementById('username-availability').textContent = ''; // Reset message if input is empty
        isUsernameAvailable = false; // Reset username availability
    }
});

// Function to validate password policy
const passwordValidator = (password) => {
    if (password.length === 0) {
        return 'Vui lòng nhập mật khẩu của bạn';
    }
    if (password.length < 8) {
        return 'Mật khẩu phải có ít nhất 8 kí tự';
    }
    if (/\s/.test(password)) {
        return 'Mật khẩu không được chứa khoảng trắng';
    }
    if (!/[A-Z]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự in hoa';
    }
    if (!/[a-z]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự là chữ thường';
    }
    if (!/[0-9]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự là số';
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return 'Mật khẩu phải có ít nhất một kí tự đặc biệt';
    }
    return '';
};

// Toggle between login and register form
document.getElementById('register-btn').addEventListener('click', function() {
    const registerForm = document.getElementById('register-form');
    const loginForm = document.getElementById('login-form');

    // Toggle display state between register and login form
    registerForm.classList.toggle('hidden');
    loginForm.classList.toggle('hidden');

    // Change button text
    this.textContent = registerForm.classList.contains('hidden') ? 'Register' : 'Back to Login';
});

// Handle submit event for register form===================================================
// document.getElementById('register-form').addEventListener('submit', function(event) {


//     // Check if username is available before submitting
//     if (!isUsernameAvailable) {
//         alert('Please choose another username!'); // Show alert if username is taken
//         event.preventDefault(); // Prevent form submission
//         return; // Stop execution
//     }
    

//     // password policy
//     const password = document.getElementById('new-password').value;
//     const validationMessage = passwordValidator(password);
//     if (validationMessage !== '') {
//         event.preventDefault(); // Prevent form submission
//         alert(validationMessage);
//         return;
//     }

// // Check password Updated 22/10 


//     //Check reCAPTCHA before submitting
//     const recaptchaResponse = grecaptcha.getResponse(1);
//     if (recaptchaResponse.length === 0) {
//         alert('Please fill in reCAPTCHA!');
//         event.preventDefault();
//         return; // Dừng nếu reCAPTCHA chưa được xác thực
//     }
// });

// Handle submit event for register form===================================================
document.getElementById('register-form').addEventListener('submit', function(event) {

    // Check if username is available before submitting
    if (!isUsernameAvailable) {
        alert('Please choose another username!'); // Show alert if username is taken
        event.preventDefault(); // Prevent form submission
        return; // Stop execution
    }

    // Password policy
    const password = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    const validationMessage = passwordValidator(password);
    if (validationMessage !== '') {
        event.preventDefault(); // Prevent form submission
        alert(validationMessage);
        return;
    }

     if (password !== confirmPassword) {
        alert('Password not match, please check your password again!'); // Show alert if passwords don't match
        event.preventDefault(); // Prevent form submission
        return; // Stop execution
    }

    // Check reCAPTCHA before submitting
    const recaptchaResponse = grecaptcha.getResponse(1);
    if (recaptchaResponse.length === 0) {
        alert('Please fill in reCAPTCHA!');
        event.preventDefault();
        return; // Stop if reCAPTCHA is not verified
    }
});


// Updated 22/10
// Real-time password matching check
const passwordInput = document.getElementById('new-password');
const confirmPasswordInput = document.getElementById('confirm-password');
const passwordMatchMessage = document.getElementById('password-match-message');

// Listen for input events on either password field
confirmPasswordInput.addEventListener('input', checkPasswordMatch);
passwordInput.addEventListener('input', checkPasswordMatch);

function checkPasswordMatch() {
    // Only show message if both fields have input
    if (passwordInput.value === '' || confirmPasswordInput.value === '') {
        passwordMatchMessage.textContent = ''; // Clear message if one or both fields are empty
        return;
    }

    // Compare passwords
    if (passwordInput.value === confirmPasswordInput.value) {
        passwordMatchMessage.textContent = 'Passwords match';
        passwordMatchMessage.style.color = 'green';
    } else {
        passwordMatchMessage.textContent = 'Password not match!';
        passwordMatchMessage.style.color = 'red';
    }
}



// =============================================================================

// Handle submit event for login form
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn form gửi đi theo cách thông thường

    // Check reCAPTCHA before submitting
    const recaptchaResponse = grecaptcha.getResponse(0);
    if (recaptchaResponse.length === 0) {
        alert('Please fill in reCAPTCHA!');
        return; // Dừng nếu reCAPTCHA chưa được xác thực
    }

    // Lấy dữ liệu từ form
    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries());

// Updated 22/10
    // Validate password match before sending request
    // if (data.password !== data['confirm-password']) {
    //     alert('Passwords do not match!');
    //     return; // Stop if passwords don't match
    // }


    // Send data to the server via the /login API
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json()) 
    .then(data => {
        if (data.success) {
            // Lưu thông tin user vào localStorage
            localStorage.setItem('userId', data.userId);
            localStorage.setItem('username', data.username);

            // Chuyển hướng tới trang customer1.html sau khi đăng nhập thành công
            window.location.href = 'customer1.html';
        } else {
            // Hiển thị lỗi nếu đăng nhập thất bại
            alert('Login failed! Please check your username and password.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while logging in.');
    });
});




// Script nút back về viewerpage.html 
// Lắng nghe sự kiện khi người dùng nhấn nút "Back"
    document.querySelector('.back-button').addEventListener('click', function() {
        // Chuyển hướng người dùng đến trang viewerpage.html
        window.location.href = 'viewerpage.html';
    });

