


function scrollToContact() {
    document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
}