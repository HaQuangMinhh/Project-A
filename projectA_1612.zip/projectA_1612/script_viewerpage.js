document.addEventListener('DOMContentLoaded', () => {
        fetch('/products')
            .then(response => response.json())
            .then(products => {
                const productList = document.getElementById('list-products');
                products.forEach(product => {
                    const formattedPrice = new Intl.NumberFormat('vi-VN').format(product.price) + ' VNĐ';
                    const productItem = `
                    
                        <li class="item product-item">
                            <img src="assets/${product.image_url}" alt="${product.name}">
                            <div class="name">${product.name}</div>
                            <div class="desc">${product.description}</div>
                            <div class="price">${formattedPrice}</div>
                        </li>`;
                    productList.innerHTML += productItem;
                });
            })
            .catch(error => console.error('Lỗi khi tải sản phẩm:', error));
    });

const next = document.querySelector('.next')
const prev = document.querySelector('.prev')
const comment = document.querySelector('#list-comment')
const commentItems = document.querySelectorAll('#list-comment .item')
// var translateY = 0
// var count = commentItem.length

// MH 10/1
let translateX = 0; 
let currentIndex = 0; 




function scrollToBanner() {
    document.getElementById('banner').scrollIntoView({ behavior: 'smooth' });
}
function scrollToProducts() {
    document.getElementById('wp-products').scrollIntoView({ behavior: 'smooth' });
}
function scrollToContact() {
    document.getElementById('footer').scrollIntoView({ behavior: 'smooth' });
}


// ============================================================================ MH 1 /10 customer feedbacks
next.addEventListener('click', function(event) {
    event.preventDefault();
    if (currentIndex < commentItems.length - 1) { // Kiểm tra nếu chưa tới item cuối
        currentIndex++;
        translateX = -100 * currentIndex; // Di chuyển tiếp theo
        comment.style.transform = `translateX(${translateX}%)`;
    }
});

prev.addEventListener('click', function(event) {
    event.preventDefault();
    if (currentIndex > 0) { // Kiểm tra nếu chưa tới item đầu
        currentIndex--;
        translateX = -100 * currentIndex; // Di chuyển ngược lại
        comment.style.transform = `translateX(${translateX}%)`;
    }
});
window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const message = urlParams.get('message');
    
    if (message) {
        alert(message); // Hiển thị thông báo nếu có
    }
};

document.getElementById('feedback-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn không cho form gửi theo cách truyền thống

    const feedback = this.feedback.value; // Lấy giá trị feedback từ ô input

    fetch('/submit-feedback', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ feedback }), // Gửi feedback dưới dạng JSON
    })
    .then(response => {
        // Xử lý phản hồi từ server nếu cần
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Có lỗi xảy ra khi gửi feedback.'); // Thông báo lỗi nếu có
    });
});