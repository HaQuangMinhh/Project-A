const express = require('express');
const { createReadStream } = require('fs');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const bcrypt = require('bcrypt');
const { randomBytes } = require('crypto');
const cookieParser = require('cookie-parser');
const mysql = require('mysql2');
const crypto = require('crypto');

const secret = crypto.randomBytes(32).toString('hex');

const app = express();
const SESSIONS = {}; // Store session ID and user information

// --------------------------------------PASSPORT GG -----------------------------------------------------------


const { OAuth2Client } = require('google-auth-library');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

// Thay thế trực tiếp các giá trị
const GOOGLE_CLIENT_ID = '1092266308342-8hrg3jv9sqtjppe3v902agm5nv80oil3.apps.googleusercontent.com'; //id của gmail quangkhim
const GOOGLE_CLIENT_SECRET = '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'; //key của quangkhim
const SESSION_SECRET = secret; // Đổi thành khóa bí mật riêng
const client = new OAuth2Client(GOOGLE_CLIENT_ID);


//================================================================= Mh updated by 2/10 làm booking
const bodyParserBooking = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true })); // Để xử lý dữ liệu từ form
//-------------------------------------------------------------------------------------------- 


// ------------------------------------------------HELMET----------------------------------------------

// const helmet = require('helmet');

// 
// app.use(helmet());



// ------------------------------------------------CSRF Protection ----------------------------------------------

// const csurf = require('csurf');

// //settup middleware CSRF
// const csrfProtection = csurf({
//     cookie: true // Sử dụng cookie để lưu trữ token
// });

// // useing middleware CSRF
// app.use(csrfProtection);

// // adding CSRF token into response
// app.use((req, res, next) => {
//     res.locals.csrfToken = req.csrfToken();
//     next();
// });

// // --------------------------------------------Command Injection Prevention-----------------------------------------------

// app.post('/command', (req, res) => {
//     const userInput = req.body.command;

//     // 
//     if (!validator.isAlphanumeric(userInput)) {
//         return res.status(400).send('Invalid input');
//     }

//     // execute Safe command
//     safeExecute(userInput);
// });

// function safeExecute(command) {
    
// }

// ----------------------------------Content Security Policy (CSP)-----------------------------------------------------

// app.use((req, res, next) => {
//     res.setHeader("Content-Security-Policy", "script-src 'self' ; style-src 'self';");
//     next();
// });

// ---------------------------------------Cookie and Session Management--------------------------------------------------

app.use(session({
    secret: secret,
    resave: false,
    saveUninitialized: false,
    cookie: {
                    secure: true,
                    httpOnly: true,
                    sameSite: 'strict',
                    maxAge: 2 * 24 * 60 * 60 * 1000  }
}));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));



// ---------------------------------------Protection Against XSS-------------------------------------------------

const escapeHtml = (unsafe) => {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
};


// ------------------------------------------------Rate Limiting----------------------------------------------

// const rateLimit = require('express-rate-limit');

// const limiter = rateLimit({
//     windowMs: 15 * 60 * 1000, // 15 mins
//     max: 100 // 
// });

// app.use(limiter);

// Too many requests, please try again later.


// ------------------------------------------------DATABASE---------------------------------------------------------------

// Connect to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '25112001', // Replace with your password
    database: 'next_door_restaurant'
});

connection.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to the database.');
});

app.get('/', (req, res) => {
    createReadStream(path.join(__dirname, 'viewerpage.html')).pipe(res);
});

app.get('/login.html', (req, res) => {
    createReadStream(path.join(__dirname, 'login.html')).pipe(res);
});


// Updated 2/10 improve HTML serving
app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});


// ----------------------------------------LOGIN ------------------------------------------------------------------------



// LOGIN
app.post('/login', async (req, res) => {
    const { googleToken, username, password } = req.body;

    if (googleToken) {
        try {
            const ticket = await client.verifyIdToken({
                idToken: googleToken,
                audience: GOOGLE_CLIENT_ID,
            });
            const payload = ticket.getPayload();
            const googleEmail = payload.email;

            connection.query('SELECT * FROM users WHERE username = ?', [googleEmail], (err, results) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
                }

                const nextSessionId = randomBytes(16).toString('hex');
                if (results.length > 0) {
                    const { id: userId, role } = results[0];
                    SESSIONS[nextSessionId] = { userId, username: googleEmail, role };

                    res.cookie('sessionId', nextSessionId, {
                        secure: false,
                        httpOnly: true,
                        sameSite: 'lax',
                        maxAge: 2 * 24 * 60 * 60 * 1000,
                    });

                    return res.json({ success: true, userId, username: googleEmail, role });
                } else {
                    const newUser = { username: googleEmail, password: null, role: 0 };
                    connection.query('INSERT INTO users SET ?', newUser, (err, result) => {
                        if (err) {
                            console.error('Error inserting user:', err);
                            return res.status(500).json({ success: false, message: 'Internal Server Error' });
                        }

                        const userId = result.insertId;
                        SESSIONS[nextSessionId] = { userId, username: googleEmail, role: 0 };

                        res.cookie('sessionId', nextSessionId, {
                            secure: false,
                            httpOnly: true,
                            sameSite: 'lax',
                            maxAge: 2 * 24 * 60 * 60 * 1000,
                        });

                        return res.json({ success: true, userId, username: googleEmail, role: 0 });
                    });
                }
            });
        } catch (error) {
            console.error('Google OAuth Error:', error);
            return res.status(401).json({ success: false, message: 'Invalid Google token' });
        }
    } else if (username && password) {
        connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
            if (err) {
                console.error('Error fetching user:', err);
                return res.status(500).json({ success: false, message: 'Internal Server Error' });
            }

            if (results.length === 0) {
                return res.json({ success: false, message: 'User does not exist. Please try again...' });
            }

            bcrypt.compare(password, results[0].password, (err, isMatch) => {
                if (err) {
                    console.error('Error comparing passwords:', err);
                    return res.status(500).json({ success: false, message: 'Internal Server Error' });
                }

                if (isMatch) {
                    const nextSessionId = randomBytes(16).toString('hex');
                    const { id: userId, role } = results[0];
                    SESSIONS[nextSessionId] = { userId, username, role };
                    console.log(`Session ID created: ${nextSessionId} for user: ${username}, role: ${role}`);


                    res.cookie('sessionId', nextSessionId, {
                        secure: false,
                        httpOnly: true,
                        sameSite: 'lax',
                        maxAge: 2 * 24 * 60 * 60 * 1000,
                    });

                    return res.json({ success: true, userId, username, role });
                } else {
                    return res.json({ success: false, message: 'Invalid password. Please try again...' });
                }
            });
        });
    } else {
        return res.status(400).json({ success: false, message: 'Missing login information' });
    }
});

// ----------------------------------OAUTH---------------------------------------------------------

// Passport Config
passport.use(new GoogleStrategy({
    clientID: GOOGLE_CLIENT_ID,
    clientSecret: GOOGLE_CLIENT_SECRET,
    callbackURL: 'http://localhost:4010/customer1.html',
}, (accessToken, refreshToken, profile, done) => {
    return done(null, profile);
}));

passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((user, done) => {
    done(null, user);
});

app.use(session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
}));

app.use(passport.initialize());
app.use(passport.session());

app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/' }),
    (req, res) => {
        res.redirect('/customer1.html');
    }
);

// Check Session
app.get('/customer1.html', (req, res) => {
    const sessionId = req.cookies.sessionId;

    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        createReadStream(path.join(__dirname, 'customer1.html')).pipe(res);
    } else {
        res.redirect('/login.html');
    }
});

// get userId from session
app.get('/getUserId', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];
    console.log('Session Data:', sessionData); // Thêm dòng này để kiểm tra
    if (sessionData) {
        res.json({ userId: sessionData.userId });
    } else {
        res.status(401).json({ error: 'User not authenticated' });
    }
});

// check session ID
app.get('/check-session', (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (sessionId && SESSIONS[sessionId]) {
        res.send(`Session ID is valid for user: ${escapeHtml(SESSIONS[sessionId].username)}`); // Escape HTML
    } else {
        res.send('Session ID is invalid or not found');
    }
});

// -----------------------------------------------------REGISTER-------------------------------------------------------


// Register
app.post('/register', (req, res) => {
    const username = escapeHtml(req.body.username);
    const password = req.body.password;
    const phoneNumber = escapeHtml(req.body.number); // Lấy số điện thoại
    const address = escapeHtml(req.body.address); // Lấy địa chỉ
    const email = escapeHtml(req.body.email); // Lấy email


    // Check email and PhoneNumber
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ message: 'Invalid email format.' });
    }

    if (!/^\d{10,15}$/.test(phoneNumber)) {
        return res.status(400).json({ message: 'Phone number must be numeric and between 10-15 digits.' });
    }


    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error checking user:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            return res.status(400).json({ message: 'User already exists. Please choose another username.' });
        }

        bcrypt.hash(password, 10, (err, hash) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.status(500).send('Internal Server Error');
            }

         
                connection.query(
                    'INSERT INTO users (username, password, phoneNumber, address, email) VALUES (?, ?, ?, ?, ?)',
                    [username, hash, phoneNumber, address, email],
                    (err, results) => {
                        if (err) {
                            console.error('Error inserting user:', err);
                            return res.status(500).send('Internal Server Error');
                        }
                        
                // Automatically login after successful registration
                const userId = results.insertId; 
                

                // Thêm dòng này vào mã đăng ký để xác nhận userId
                // console.log('User ID after registration:', userId); // Xác nhận userId được tạo

                const role = 0; 
                const nextSessionId = randomBytes(16).toString('hex');
                SESSIONS[nextSessionId] = { userId, username, role };

                console.log(`Session ID created: ${nextSessionId} for user: ${username}, role: ${role}`);

                res.cookie('sessionId', nextSessionId, {
                    secure: true,
                    httpOnly: true,
                    sameSite: 'lax',
                    maxAge: 2 * 24 * 60 * 60 * 1000 // 2 d
                });

                
                res.redirect('/customer1.html?message=Registration successful! You can now log in.');
            });
        });
    });
});



// ---------------------------------CHECK USERNAME-------------------------------------------------------


// Check username availability
app.get('/check-username', (req, res) => {
    const username = escapeHtml(req.query.username); // Lấy tên người dùng từ truy vấn

    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error checking username:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }

        // Trả về true nếu tên người dùng đã tồn tại, false nếu chưa
        const isAvailable = results.length === 0;
        res.json({ available: isAvailable });
    });
});






// -----------------------------------------------------ReCAPTCHA---------------------------------------------------

const axios = require('axios');

// Xử lý login form
app.post('/login', async (req, res) => {
  const recaptchaResponse = req.body['g-recaptcha-response']; // Nhận reCAPTCHA response từ login form
  const secretKey = '6LeWXU8qAAAAAHMIVsccdRqe9hT06rS-uvNqeNaR'; // Secret Key cho login từ Google

  const response = await axios.post(`https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptchaResponse}`);
  const captchaValid = response.data.success;

  if (captchaValid) {
    // CAPTCHA hợp lệ, xử lý tiếp form đăng nhập
    res.json({ success: true, userId: 1, username: 'User' });
  } else {
    // CAPTCHA không hợp lệ
    res.json({ success: false });
  }
});

// Xử lý register form
app.post('/register', async (req, res) => {
  const recaptchaResponse = req.body['g-recaptcha-response']; // Nhận reCAPTCHA response từ register form
  const secretKey = '6LcAslsqAAAAADonyj-wchs4Lp2TGqhocv7ooTxm'; // Secret Key cho register từ Google

  const response = await axios.post(`https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptchaResponse}`);
  const captchaValid = response.data.success;

  if (captchaValid) {
    // CAPTCHA hợp lệ, xử lý tiếp form đăng ký
    res.json({ success: true });
  } else {
    // CAPTCHA không hợp lệ
    res.json({ success: false });
  }
});


// ---------------------------------------------LOGOUT + CHECK FOR LOGIN---------------------------------------------

// Logout
app.get('/logout', (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (SESSIONS[sessionId]) {
        delete SESSIONS[sessionId];
        res.clearCookie('sessionId', {
            secure: true,
            httpOnly: true,
            sameSite: 'lax'
        });
    }
    res.redirect('/');
});
app.post('/logout', (req, res) => {
    if (req.session) {
        req.session.destroy(err => {
            if (err) {
                return res.status(500).send('Could not log out. Please try again.');
            }
            res.sendStatus(200);
        });
    } else {
        res.sendStatus(200);
    }
});


//if user not login, redirect to login
app.get('/customer1.html', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        createReadStream(path.join(__dirname, 'customer1.html')).pipe(res);
    } else {
        res.redirect('/login.html');
    }
});



// ---------------------------------------------Send Feedback & DISPLAY ----------------------------------------------------------------

//SEND FEEDBACK
app.post('/submit-feedback', (req, res) => {
    const feedback = req.body.feedback; // Lấy giá trị từ ô email

    // In ra giá trị feedback nhận được
    console.log('Received feedback:', feedback);

    const sql = 'INSERT INTO contact_feedbacks (feedback) VALUES (?)';

    connection.query(sql, [feedback], (error, results) => {
        if (error) {
            console.error('Error inserting email:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
         // Chuyển hướng về trang chính với thông điệp
        res.redirect('/?message=Feedback sent successfully!');
    });
});

// Route để lấy phản hồi từ bảng contact_feedbacks
app.get('/feedbacks', (req, res) => {
    const query = 'SELECT * FROM contact_feedbacks ORDER BY created_at ASC';
    connection.query(query, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database query failed' });
        }
        // console.log(results); // In ra kết quả để kiểm tra
        res.json(results); // Trả về kết quả dưới dạng JSON
    });
});




// ---------------------------------------------MENU ----------------------------------------------------------------

// get menu viewer + customer
app.get('/products', (req, res) => {
    connection.query('SELECT * FROM products', (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
        // console.log('Products:', results);
    });
});  


// -----------------------------------------------------CUSTOMER----------------------------------------------------------

//Get logging's username + role 
app.get('/account', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (!sessionData) {
        return res.status(401).send('Unauthorized');
    }

    const query = 'SELECT role FROM users WHERE id = ?';
    connection.query(query, [sessionData.userId], (err, results) => {
        if (err) {
            console.error('Error fetching role:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            res.json({
                username: escapeHtml(sessionData.username), // Escape HTML
                role: results[0].role,
            });
        } else {
            res.status(404).send('User not found');
        }
    });
});

app.get('/products1', (req, res) => {
    const query = 'SELECT * FROM products';

    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).send('Internal Server Error');
        }
        res.json(results); // Trả về danh sách sản phẩm
    });
});


app.use(express.json()); // dùng json để dúng dụng cho vc update món

// Cấu hình multer để lưu tệp
const multer = require('multer');
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Lưu ảnh vào thư mục 'uploads'
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Đặt tên ảnh với timestamp
    }
});

const upload = multer({ storage: storage });

//API update món 
app.put('/products/:id', upload.single('image'), (req, res) => {
    const { id } = req.params;
    const { name, description, price, image_url } = req.body;

    console.log('Product updated: ' + JSON.stringify(req.body));

    // Kiểm tra dữ liệu đầu vào
    if (!name || !description || !price) {
        return res.status(400).json({
            error: 'Name, description, and price are required.',
            missingFields: !name ? 'name' : !description ? 'description' : 'price'
        });
    }

    // Kiểm tra id hợp lệ
    if (isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid product ID.' });
    }

    // Kiểm tra giá trị của price
    if (isNaN(Number(price)) || Number(price) < 0) {
        return res.status(400).json({ error: 'Price must be a non-negative number.' });
    }

    let finalImageUrl = image_url || ''; // Nếu không có URL ảnh mới, giữ nguyên giá trị cũ

    // Nếu người dùng upload ảnh mới, lấy tên tệp từ multer
    if (req.file) {
        finalImageUrl = req.file.filename; // Chỉ lấy tên tệp (không có đường dẫn đầy đủ)
    }

    const query = `
        UPDATE products 
        SET name = ?, description = ?, price = ?, image_url = ? 
        WHERE id = ?
    `;

    connection.query(query, [name, description, price, finalImageUrl, id], (error, result) => {
        if (error) {
            console.error(`Error updating product with ID ${id}:`, error);
            return res.status(500).json({ error: 'Failed to update product.' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Product not found.' });
        }

        res.status(200).json({ message: 'Product updated successfully.' });
    });
});



// Save invoice
app.use(express.json());
app.post('/create-invoice', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (!sessionData) {
        console.error('Session data not found');
        return res.status(401).send('Unauthorized');
    }

    const userId = sessionData.userId;
    const items = req.body.items;

    
     // Kiểm tra dữ liệu items
    if (!userId || !Array.isArray(items) || items.length === 0) {
        console.error('No items found in the request.');
        return res.status(400).json({ message: 'Cannot create invoice without items.' });
    }

    console.log('User ID:', userId);
    console.log('Items:', items);

    
    // count amount of inovoices
    let totalAmount = 0;
    items.forEach(item => {
        if (item.price && item.quantity) {
            totalAmount += item.price * item.quantity;
        } else {
            console.error('Invalid item data:', item);
            return res.status(400).send('Invalid item data');
        }
    });
    console.log("total", totalAmount)

    // Save in4 of inovice into table invoices
    connection.query('INSERT INTO invoices (user_id, total_amount) VALUES (?, ?)', [userId, totalAmount], (err, result) => {
        if (err) {
            console.error('Error saving invoice:', err);
            return res.status(500).send('Internal Server Error: ' + err.message);
        }

        const invoiceId = result.insertId;

        // save in4 into table invoice_items
        const invoiceItems = items.map(item => [invoiceId, item.id, item.price, item.quantity]);
        connection.query('INSERT INTO invoice_items (invoice_id, product_id, price, quantity) VALUES ?', [invoiceItems], (err) => {
            if (err) {
                console.error('Error saving invoice items:', err);
                return res.status(500).send('Internal Server Error: ' + err.message);
            }

            // print inovoice id 
            res.json({ invoiceId });

        });
    });
});


// -----------------------------------------------------------INVOICES------------------------------------------------------
//get invoices
app.get('/get-invoices', (req, res) => {
    const userId = req.session.userId; // assuming session middleware is used for authentication
    const query = `
        SELECT id, total_amount, created_at 
        FROM invoices 
        WHERE user_id = ? 
        ORDER BY created_at DESC`;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching invoices:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});


// -----------------------------------------ACCOUNT MAGAGEMENT--------------------------------------------------------------------

// check if it is admin or not
    app.get('/account.html', (req, res) => {
        const sessionId = req.cookies.sessionId;
        const sessionData = SESSIONS[sessionId];

        if (sessionData && sessionData.role === 1) { 
            createReadStream(path.join(__dirname, 'account.html')).pipe(res);
        } else {
            // if it isnot admin, redirct to customer
            res.redirect('/accountUser.html');
        }
        
    });


// API to get user's name 
app.get('/users', (req, res) => {
    connection.query('SELECT id, username, role FROM users', (err, results) => {
        if (err) {
            console.error('Error fetching users:', err);
            return res.status(500).send('Error fetching users');
        }
        res.json(results);
    });
});

// upgrade role to Admin
app.put('/upgrade-user/:id', (req, res) => {
    const userId = req.params.id;
    const sql = 'UPDATE users SET role = 1 WHERE id = ?';

    connection.query(sql, [userId], (err, result) => {
        if (err) {
            console.error('Error upgrading user role:', err); // In ra lỗi chi tiết
            return res.status(500).json({ error: 'Failed to upgrade user role' });
        }
        if (result.affectedRows === 0) { // Kiểm tra xem có hàng nào bị ảnh hưởng không
            return res.status(404).json({ error: 'User not found' });
        }
        res.json({ message: 'User upgraded to Admin successfully!' });
    });
});

//downgrade to User
app.put('/downgrade-user/:id', (req, res) => {
    const userId = req.params.id;
    const sql = 'UPDATE users SET role = 0 WHERE id = ?';

    connection.query(sql, [userId], (err, result) => {
        if (err) {
            console.error('Error upgrading user role:', err); // In ra lỗi chi tiết
            return res.status(500).json({ error: 'Failed to upgrade user role' });
        }
        if (result.affectedRows === 0) { // Kiểm tra xem có hàng nào bị ảnh hưởng không
            return res.status(404).json({ error: 'User not found' });
        }
        res.json({ message: 'Admin downgraded to User successfully!' });
    });
});


// API to delete user
app.delete('/delete-user/:id', (req, res) => {
    const userId = req.params.id;

    connection.query(
        'DELETE FROM users WHERE id = ?',
        [userId],
        (err, results) => {
            if (err) {
                console.error('Error deleting user:', err);
                return res.status(500).send('Error deleting user');
            }
            res.sendStatus(200);
        }
    );
});

// API to view details 

// API: Lấy thông tin chi tiết của người dùng theo ID
app.get('/user/:id', (req, res) => {
    const userId = req.params.id;

    const query = `
        SELECT username, firstName, lastName, email, phoneNumber, bio
        FROM users 
        WHERE id = ?
    `;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user info:', err);
            return res.status(500).send('Internal server error');
        }

        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).send('User not found');
        }
    });
});

// API: Cập nhật thông tin user


// Cập nhật thông tin người dùng
app.post('/user/update', async (req, res) => {
    const { username, firstName, lastName, email, phoneNumber, password, bio } = req.body;

    // Kiểm tra nếu không có username
    if (!username) {
        return res.json({ success: false, message: 'Username is missing or invalid.' });
    }


    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        return res.json({ success: false, message: 'Invalid email format.' });
    }

    const phonePattern = /^[+]?[0-9]{10,15}$/;
    if (!phonePattern.test(phoneNumber)) {
        return res.json({ success: false, message: 'Invalid phone format.' });
    }


     try {
        // Hash mật khẩu nếu có
        let hashedPassword = null;
        if (password) {
            const saltRounds = 10; // Đảm bảo bạn đã định nghĩa số vòng "salt"
            hashedPassword = await bcrypt.hash(password, saltRounds);
        }

        // Tạo câu truy vấn cập nhật
        let query = `
            UPDATE users 
            SET 
                firstName = ?, 
                lastName = ?, 
                email = ?, 
                phoneNumber = ?, 
                bio = ?
        `;
        const queryParams = [firstName, lastName, email, phoneNumber, bio];

        // Nếu có mật khẩu mới, thêm vào câu truy vấn
        if (hashedPassword) {
            query += `, password = ?`;
            queryParams.push(hashedPassword);
        }

        query += ` WHERE username = ?`; // Điều kiện dựa trên username
        queryParams.push(username);

        

        // Thực hiện truy vấn
        connection.query(query, queryParams, (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.json({ success: false, message: 'Database error.' });
            }

            if (result.affectedRows === 0) {
                return res.json({ success: false, message: 'No rows updated. Check if the username exists.' });
            }

            return res.json({ success: true, message: 'User details updated successfully.' });
        });
    } catch (error) {
        console.error('Server error:', error);
        return res.json({ success: false, message: 'Server error while updating user details.' });
    }
    
          
});

// ---------------------------------------------------Account User -------------------------------------

// API: Lấy thông tin người dùng và gửi đến accountUser.html
app.get('/accountUserInfo', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (!sessionData) {
        return res.status(401).send('Unauthorized');
    }

    const userId = sessionData.userId;

    const query = `
        SELECT username, firstName, lastName, email, phoneNumber, bio
        FROM users 
        WHERE id = ?
    `;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user info:', err);
            return res.status(500).send('Internal server error');
        }

        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).send('User not found');
        }
    });
});

// Middleware
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/update-user-details', (req, res) => {
    
    console.log('Received data:', req.body); // show trong CMD

    const { username, firstName, lastName, email, phoneNumber, password, bio } = req.body;

    const sessionId = req.cookies.sessionId; // Lấy session để xác định user
    const sessionData = SESSIONS[sessionId];
    
    if (!sessionData) {
        return res.status(401).send('Unauthorized');
    }

    const userId = sessionData.userId; // Lấy userId từ session
    if (!userId) {
        return res.status(401).send('User not authenticated.');
    }

    // Log dữ liệu từng trường để chắc chắn chúng có đầy đủ
    console.log('Username:', username);
    console.log('FirstName:', firstName);
    console.log('LastName:', lastName);
    console.log('Email:', email);
    console.log('PhoneNumber:', phoneNumber);
    console.log('Password:', password);
    console.log('Bio:', bio);

    
    // Kiểm tra lại dữ liệu ở server (tăng độ an toàn)
    if (!username || !firstName || !lastName || !email || !phoneNumber || !password || !bio) {
        return res.json({ success: false, message: 'All fields are required.' });
    }

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        return res.json({ success: false, message: 'Invalid email format.' });
    }

    const phonePattern = /^[+]?[0-9]{10,15}$/;
    if (!phonePattern.test(phoneNumber)) {
        return res.json({ success: false, message: 'Invalid phone format.' });
    }

    // Kiểm tra policy mật khẩu
    if (password.length < 8) {
        return res.json({ success: false, message: 'Password must be at least 8 characters.' });
    }
    if (/\s/.test(password)) {
        return res.json({ success: false, message: 'Password must not contain spaces.' });
    }
    if (!/[A-Z]/.test(password)) {
        return res.json({ success: false, message: 'Password must contain at least one uppercase letter.' });
    }
    if (!/[a-z]/.test(password)) {
        return res.json({ success: false, message: 'Password must contain at least one lowercase letter.' });
    }
    if (!/[0-9]/.test(password)) {
        return res.json({ success: false, message: 'Password must contain at least one number.' });
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return res.json({ success: false, message: 'Password must contain at least one special character.' });
    }

    // Mã hóa mật khẩu trước khi lưu
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            return res.json({ success: false, message: 'Error hashing password.' });
        }

        // Lấy username cũ nếu username mới không được gửi
        const getCurrentUsernameQuery = 'SELECT username FROM users WHERE id = ?';
        
        connection.query(getCurrentUsernameQuery, [userId], (err, results) => {
            if (err || results.length === 0) {
                console.error('Error fetching current username:', err);
                return res.json({ success: false, message: 'Database error.' });
            }

            const currentUsername = results[0].username;
            const newUsername = username || currentUsername;

            // Cập nhật thông tin
            const updateQuery = `
                UPDATE users 
                SET 
                    username = ?, 
                    firstName = ?, 
                    lastName = ?, 
                    email = ?, 
                    phoneNumber = ?, 
                    password = ?, 
                    bio = ? 
                WHERE id = ?
            `;

            connection.query(updateQuery, [newUsername, firstName, lastName, email, phoneNumber, hashedPassword, bio, userId], (err) => {
                if (err) {
                    console.error('Error updating user details:', err);
                    return res.json({ success: false, message: 'Database error.' });
                }
                return res.json({ success: true });
            });
        });
    });
});


// -----------------------------------------ELSE--------------------------------------------------------------------


// Other routes
app.get('/invoice.html', (req, res) => {
    createReadStream('invoice.html').pipe(res);
});
app.get('/feedback.html', (req, res) => {
    createReadStream('feedback.html').pipe(res);
});
app.get('/style_login.css', (req, res) => {
    createReadStream('style_login.css').pipe(res);
});
app.get('/login_style.css', (req, res) => {
    createReadStream('./login_style.css').pipe(res);
});
app.get('/style_viewerpage.css', (req, res) => {
    createReadStream('./style_viewerpage.css').pipe(res);
});
app.get('/script_viewerpage.js', (req, res) => {
    createReadStream('./script_viewerpage.js').pipe(res);
});
app.get('/script_login.js', (req, res) => {
    createReadStream('./script_login.js').pipe(res);
});
app.get('/style_customer.css', (req, res) => {
    createReadStream('./style_customer.css').pipe(res);
});
app.get('/script_customer.js', (req, res) => {
    createReadStream('./script_customer.js').pipe(res);
});
app.get('/script_invoice.js', (req, res) => {
    createReadStream('./script_invoice.js').pipe(res);
});
app.get('/style_invoice.css', (req, res) => {
    createReadStream('./style_invoice.css').pipe(res);
});
app.get('/script_account.js', (req, res) => {
    createReadStream('./script_account.js').pipe(res);
});
app.get('/style_account.css', (req, res) => {
    createReadStream('./style_account.css').pipe(res);
});
app.get('/style_feedback.css', (req, res) => {
    createReadStream('./style_feedback.css').pipe(res);
});
app.get('/overview.html', (req, res) => {
    createReadStream('./overview.html').pipe(res);
});
app.get('/style_overview.css', (req, res) => {
    createReadStream('./style_overview.css').pipe(res);
});
app.get('/script_overview.js', (req, res) => {
    createReadStream('./script_overview.js').pipe(res);
});
app.get('/events.html', (req, res) => {
    createReadStream('./events.html').pipe(res);
});
app.get('/style_events.css', (req, res) => {
    createReadStream('./style_events.css').pipe(res);
});
app.get('/script_events.js', (req, res) => {
    createReadStream('./script_events.js').pipe(res);
});
app.get('/booking.html', (req, res) => {
    createReadStream('./booking.html').pipe(res);
});
app.get('/style_booking.css', (req, res) => {
    createReadStream('./style_booking.css').pipe(res);
});
app.get('/script_booking.js', (req, res) => {
    createReadStream('./script_booking.js').pipe(res);
});
// app.get('/displayBooking.html', (req, res) => {
//     createReadStream('./displayBooking.html').pipe(res);
// });
app.get('/script_feedback.js', (req, res) => {
    createReadStream('./script_feedback.js').pipe(res);
});
app.get('/viewerpage.html', (req, res) => {
    createReadStream('./viewerpage.html').pipe(res);
});
app.get('/accountUser.html', (req, res) => {
    createReadStream('./accountUser.html').pipe(res);
});
app.get('/style_accountUser.css', (req, res) => {
    createReadStream('./style_accountUser.css').pipe(res);
});
app.get('/script_accountUser.js', (req, res) => {
    createReadStream('./script_accountUser.js').pipe(res);
});

// -------------------------------------------------IMAGES--------------------------------------------------------------


// Load images
const assets = [
    'logo.png', 'user.png', 'cart.png', 'img_1.png', 'img_2.png',
    'img_3.png', 'to_bottom.png', 'product_1.png', 'product_2.png',
    'product_3.png', 'product_4.png', 'product_5.png', 'product_6.png',
    'prev.png', 'avatar_1.png', 'star.png', 'next.png', 'banner.png',
    'off.png', 


    // Load images của Events, Booking, Overview
    'batch_KAL03797.webp', 'batch_KAL03797gfdg.jpg', 'batch_KAL04017.jpg', 'batch_KAL04039.jpg', 'batch_moo-beef-st-1.jpg',
    'batch_moo-beef-st-2.jpg', 'batch_moo-beef-st-4.jpg', 'batch_moo-beef-st-5.jpg', 'thiet-ke-nha-hang-5.jpg', 'batch_DSC06648.webp',
    'batch_KAL037978.jpg', 'batch_KAL03801.webp', 'batch_TRM08847.webp', 'quotes.jpg' , 'anh44.jpeg' , 'viewanh2.jpg' ,


    // Load images of Events 
    'event1.webp', 'event2.webp', 'event3.webp', 'event4.webp', 'event5.webp', 'event6.webp', 'event7.webp',
    'event8.webp', 'event9.webp', 'event10.webp', 'event11.webp', 'event12.webp',

    'event22.webp', 'event23.webp', 'event24.webp', 'event25.webp', 'event26.webp', 'event27.webp', 'event28.webp',
    'event29.webp', 'event30.webp',

    'valen1.webp', 'valen2.webp', 'valen3.webp', 'valen4.webp', 'valen5.webp', 'valen6.webp', 'valen7.webp',
    'valen8.webp', 'valen9.webp', 'valen10.webp',

    // some food 
    'product8.png' , 'product9.png' , 'product10.png' , 'product11.png' ,'product12.png' ,
    'product13.png' , 'product14.png' , 'product15.png' ,'product16.png' ,'product17.png' ,
    'product18.png' ,

    // new food Updated 30/10 use in viewpaper and menu in customer1.html 
    'food1.png', 'food2.png','food3.png','food4.png','food5.png','food6.png',
    'food7.png','food8.png','food9.png', 


];


// Create routes for each image in the list
assets.forEach(asset => {
    app.get(`/assets/${asset}`, (req, res) => {
        createReadStream(path.join(__dirname, 'assets', asset)).pipe(res);
    });
});

// -----------------------------------------BOOKING-------------------------------------------------------


app.post('/booking', (req, res) => {
    const { name, datetime, quantity, email, phone, message } = req.body; // Lấy dữ liệu từ form

    // Tạo câu truy vấn SQL để lưu dữ liệu vào cơ sở dữ liệu
    const query = 'INSERT INTO bookings (name, datetime, quantity, email, phone, message) VALUES (?, ?, ?, ?, ?, ?)';
    
    connection.query(query, [name, datetime, quantity, email, phone, message], (error, results) => {
        if (error) {
            console.error('Error inserting data:', error);
            return res.status(500).send('Error inserting data'); // Gửi mã lỗi nếu có vấn đề với cơ sở dữ liệu
        }
        else{
                res.redirect('/Booking.html');
            }

    });
});


// -----------------------------------------Display BOOKING---------------------------------------------

// check if it is admin or not
    app.get('/displayBooking.html', (req, res) => {
        const sessionId = req.cookies.sessionId;
        const sessionData = SESSIONS[sessionId];

        if (sessionData && sessionData.role === 1) { 
            createReadStream(path.join(__dirname, 'displayBooking.html')).pipe(res);
        } else {
            // if it isnot admin, redirct to customer
            res.redirect('/customer1.html?message=Only admin is allowed to access Booking List!');
        }
        
    });

// Route để lấy thông tin bookings
app.get('/bookings', (req, res) => {
    const query = 'SELECT * FROM bookings';
    connection.query(query, (err, results) => {
        if (err) throw err;
        res.json(results); // Trả về kết quả dưới dạng JSON
    });
});

// Route để xóa một booking
app.delete('/bookings/:id', (req, res) => {
    const bookingId = req.params.id;
    const query = 'DELETE FROM bookings WHERE id = ?';
    connection.query(query, [bookingId], (err, results) => {
        if (err) {
            res.status(500).send('Error deleting booking');
        } else {
            res.status(200).send('Booking deleted successfully');
        }
    });
});



// //------------------------------------------------------------------------ Endpoint cho gooogle sign-in
//  // Google Sign-In
// // ---------------------------------------------------------- Cấu hình OAuth Client
// const { OAuth2Client } = require('google-auth-library');


// const GOOGLE_CLIENT_ID = '446639244371-cnalbg24etn6fu2feato4mo725ta8iu3.apps.googleusercontent.com';
// app.post('/tokensignin', (req, res) => {
//     const { id_token } = req.body;

//     const client = new OAuth2Client(GOOGLE_CLIENT_ID); // Thay YOUR_GOOGLE_CLIENT_ID bằng ID thực tế
//     client.verifyIdToken({
//         idToken: id_token,
//         audience: GOOGLE_CLIENT_ID,
//     })
//     .then(ticket => {
//         const payload = ticket.getPayload();
//         const userid = payload['sub'];

//         const nextSessionId = randomBytes(16).toString('hex');
//         SESSIONS[nextSessionId] = { userId: userid, username: payload.name, role: 0 };

//         res.cookie('sessionId', nextSessionId, {
//             secure: true,
//             httpOnly: true,
//             sameSite: 'lax',
//             maxAge: 2 * 24 * 60 * 60 * 1000 // 2 days
//         });

//         res.json({ success: true, userId: userid, username: payload.name });
//     })
//     .catch(err => {
//         console.error('Error verifying Google ID token:', err);
//         res.status(401).json({ success: false, message: 'Invalid ID token' });
//     });
// });


// // Facebook Sign-In
// // Facebook sign-in endpoint
// app.post('/facebook-signin', (req, res) => {
//     const { accessToken } = req.body;

//     // Lấy thông tin người dùng từ Facebook
//     fetch(`https://graph.facebook.com/me?access_token=${accessToken}&fields=id,name,email`)
//         .then(response => response.json())
//         .then(data => {
//             if (data && data.id) {
//                 const nextSessionId = randomBytes(16).toString('hex');
//                 SESSIONS[nextSessionId] = { userId: data.id, username: data.name, role: 0 }; // role có thể thay đổi tùy theo hệ thống

//                 res.cookie('sessionId', nextSessionId, {
//                     secure: process.env.NODE_ENV === 'production', // Bảo mật cookie trên môi trường sản xuất
//                     httpOnly: true,
//                     sameSite: 'lax',
//                     maxAge: 2 * 24 * 60 * 60 * 1000 // 2 days
//                 });

//                 // Trả về thông tin người dùng
//                 res.json({ success: true, userId: data.id, username: data.name });
//             } else {
//                 res.status(401).json({ success: false, message: 'Invalid access token' });
//             }
//         })
//         .catch(err => {
//             console.error('Error fetching Facebook user data:', err);
//             res.status(500).json({ success: false, message: 'Internal Server Error' });
//         });
// });

// // cookie sử dụng trong server
// app.use(cookieParser());
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));



// // Update Client-side script =========================================== Update 7/10 
// function statusChangeCallback(response) {
//     if (response.status === 'connected') {
//         const accessToken = response.authResponse.accessToken;

//         fetch('/facebook-signin', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({ accessToken })
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 window.location.href = 'customer1.html';
//             } else {
//                 alert(data.message || 'Facebook Sign-In failed'); // Thay thế ở đây
//             }
//         })
//         .catch(error => {
//             console.error('Error during Facebook Sign-In:', error);
//             alert('An error occurred during Facebook Sign-In. Please try again.'); // Thêm đoạn này để xử lý lỗi
//         });
//     } else {
//         console.log('Not authenticated');
//     }
// }


// -------------------------------------------------------------------------------------------
app.listen(4010, () => {
    console.log('Server running on http://localhost:4010');
});
