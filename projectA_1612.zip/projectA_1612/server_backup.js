const express = require('express');
const { createReadStream } = require('fs');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const bcrypt = require('bcrypt');
const { randomBytes } = require('crypto');
const cookieParser = require('cookie-parser');
const mysql = require('mysql2');
const crypto = require('crypto');

const secret = crypto.randomBytes(32).toString('hex');

const app = express();
const SESSIONS = {}; // Store session ID and user information

// ------------------------------------------------HELMET----------------------------------------------

// const helmet = require('helmet');

// 
// app.use(helmet());



// ------------------------------------------------CSRF Protection ----------------------------------------------

// const csurf = require('csurf');

// //settup middleware CSRF
// const csrfProtection = csurf({
//     cookie: true // Sử dụng cookie để lưu trữ token
// });

// // useing middleware CSRF
// app.use(csrfProtection);

// // adding CSRF token into response
// app.use((req, res, next) => {
//     res.locals.csrfToken = req.csrfToken();
//     next();
// });

// // --------------------------------------------Command Injection Prevention-----------------------------------------------

// app.post('/command', (req, res) => {
//     const userInput = req.body.command;

//     // 
//     if (!validator.isAlphanumeric(userInput)) {
//         return res.status(400).send('Invalid input');
//     }

//     // execute Safe command
//     safeExecute(userInput);
// });

// function safeExecute(command) {
    
// }

// ----------------------------------Content Security Policy (CSP)-----------------------------------------------------

app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", "script-src 'self' ; style-src 'self';");
    next();
});

// ---------------------------------------Cookie and Session Management--------------------------------------------------

app.use(session({
    secret: secret,
    resave: false,
    saveUninitialized: false,
    cookie: {
                    secure: true,
                    httpOnly: true,
                    sameSite: 'strict',
                    maxAge: 2 * 24 * 60 * 60 * 1000  }
}));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));



// ---------------------------------------Protection Against XSS-------------------------------------------------

const escapeHtml = (unsafe) => {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
};


// ------------------------------------------------Rate Limiting----------------------------------------------

const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 mins
    max: 100 // 
});

app.use(limiter);

// Too many requests, please try again later.


// ------------------------------------------------DATABASE---------------------------------------------------------------

// Connect to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '141102', // Replace with your password
    database: 'next_door_restaurant'
});

connection.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to the database.');
});

app.get('/', (req, res) => {
    createReadStream(path.join(__dirname, 'viewerpage.html')).pipe(res);
});

app.get('/login.html', (req, res) => {
    createReadStream(path.join(__dirname, 'login.html')).pipe(res);
});





// ----------------------------------------LOGIN & SIGN UP---------------------------------------------------------------------------

// LOGIN
app.post('/login', (req, res) => {
    const username = escapeHtml(req.body.username);
    const password = req.body.password;

    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ success: false, message: 'Internal Server Error' });
        }

        if (results.length === 0) {
            return res.json({ success: false, message: 'User does not exist. Please try again...' });
        }

        bcrypt.compare(password, results[0].password, (err, isMatch) => {
            if (err) {
                console.error('Error comparing passwords:', err);
                return res.status(500).json({ success: false, message: 'Internal Server Error' });
            }

            if (isMatch) {
                const nextSessionId = randomBytes(16).toString('hex');
                const userId = results[0].id;
                const role = results[0].role;
                SESSIONS[nextSessionId] = { userId, username, role };

                console.log(`Session ID created: ${nextSessionId} for user: ${username}, role: ${role}`);

                res.cookie('sessionId', nextSessionId, {
                    secure: true,
                    httpOnly: true,
                    sameSite: 'lax',
                    maxAge: 2 * 24 * 60 * 60 * 1000 // 2 days
                });

                res.json({ success: true, userId, username, role });
            } else {
                res.json({ success: false, message: 'Invalid password. Please try again...' });
            }
        });
    });
});

// Check Session
app.get('/customer1.html', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        createReadStream(path.join(__dirname, 'customer1.html')).pipe(res);
    } else {
        res.redirect('/login.html');
    }
});

// get userId from session
app.get('/getUserId', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        res.json({ userId: sessionData.userId });
    } else {
        res.status(401).json({ error: 'User not authenticated' });
    }
});

// check session ID
app.get('/check-session', (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (sessionId && SESSIONS[sessionId]) {
        res.send(`Session ID is valid for user: ${escapeHtml(SESSIONS[sessionId].username)}`); // Escape HTML
    } else {
        res.send('Session ID is invalid or not found');
    }
});



// Register
app.post('/register', (req, res) => {
    const username = escapeHtml(req.body.username);
    const password = req.body.password;

    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error checking user:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            return res.status(400).send('User already exists. Please choose another username.');
        }

        bcrypt.hash(password, 10, (err, hash) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.status(500).send('Internal Server Error');
            }

            connection.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], (err) => {
                if (err) {
                    console.error('Error inserting user:', err);
                    return res.status(500).send('Internal Server Error');
                }

                // Automatically login after successful registration
                const nextSessionId = randomBytes(16).toString('hex');
                const userId = results.insertId; 
                const role = 0; 
                SESSIONS[nextSessionId] = { userId, username, role };

                console.log(`Session ID created: ${nextSessionId} for user: ${username}, role: ${role}`);

                res.cookie('sessionId', nextSessionId, {
                    secure: true,
                    httpOnly: true,
                    sameSite: 'lax',
                    maxAge: 2 * 24 * 60 * 60 * 1000 // 2 d
                });

                
                res.redirect('/customer1.html?message=Registration successful! You can now log in.');
            });
        });
    });
});


// Logout
app.get('/logout', (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (SESSIONS[sessionId]) {
        delete SESSIONS[sessionId];
        res.clearCookie('sessionId', {
            secure: true,
            httpOnly: true,
            sameSite: 'lax'
        });
    }
    res.redirect('/');
});
app.post('/logout', (req, res) => {
    if (req.session) {
        req.session.destroy(err => {
            if (err) {
                return res.status(500).send('Could not log out. Please try again.');
            }
            res.sendStatus(200);
        });
    } else {
        res.sendStatus(200);
    }
});


//if user not login, redirect to login
app.get('/customer1.html', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        createReadStream(path.join(__dirname, 'customer1.html')).pipe(res);
    } else {
        res.redirect('/login.html');
    }
});


//Get logging's username 
app.get('/account', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (sessionData) {
        res.json({ username: escapeHtml(sessionData.username) }); // Escape HTML
    } else {
        res.status(401).send('Unauthorized');
    }
});

// ---------------------------------------------MENU & INVOICE----------------------------------------------------------------

// get menu
app.get('/products', (req, res) => {
    connection.query('SELECT * FROM products', (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});



// Save invoice
app.use(express.json());
app.post('/create-invoice', (req, res) => {
    const sessionId = req.cookies.sessionId;
    const sessionData = SESSIONS[sessionId];

    if (!sessionData) {
        console.error('Session data not found');
        return res.status(401).send('Unauthorized');
    }

    const userId = sessionData.userId;
    const items = req.body.items;

    if (!userId || !Array.isArray(items) || items.length === 0) {
        console.error('Invalid input data:', { userId, items });
        return res.status(400).send('Invalid input data');
    }

    console.log('User ID:', userId);
    console.log('Items:', items);

    // count amount of inovoices
    let totalAmount = 0;
    items.forEach(item => {
        if (item.price && item.quantity) {
            totalAmount += item.price * item.quantity;
        } else {
            console.error('Invalid item data:', item);
            return res.status(400).send('Invalid item data');
        }
    });
    console.log("total", totalAmount)

    // Save in4 of inovice into table invoices
    connection.query('INSERT INTO invoices (user_id, total_amount) VALUES (?, ?)', [userId, totalAmount], (err, result) => {
        if (err) {
            console.error('Error saving invoice:', err);
            return res.status(500).send('Internal Server Error: ' + err.message);
        }

        const invoiceId = result.insertId;

        // save in4 into table invoice_items
        const invoiceItems = items.map(item => [invoiceId, item.id, item.price, item.quantity]);
        connection.query('INSERT INTO invoice_items (invoice_id, product_id, price, quantity) VALUES ?', [invoiceItems], (err) => {
            if (err) {
                console.error('Error saving invoice items:', err);
                return res.status(500).send('Internal Server Error: ' + err.message);
            }

            // print inovoice id 
            res.json({ invoiceId });

        });
    });
});



//get invoices
app.get('/get-invoices', (req, res) => {
    const userId = req.session.userId; // assuming session middleware is used for authentication
    const query = `
        SELECT id, total_amount, created_at 
        FROM invoices 
        WHERE user_id = ? 
        ORDER BY created_at DESC`;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching invoices:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});


// -----------------------------------------ACCOUNT MAGAGEMENT--------------------------------------------------------------------

// check if it is admin or not
    app.get('/account.html', (req, res) => {
        const sessionId = req.cookies.sessionId;
        const sessionData = SESSIONS[sessionId];

        if (sessionData && sessionData.role === 1) { 
            createReadStream(path.join(__dirname, 'account.html')).pipe(res);
        } else {
            // if it isnot admin, redirct to customer
            res.redirect('/customer1.html?message=Only admin is allowed to access Account!');
        }
        
    });


// API to get user's name 
app.get('/users', (req, res) => {
    connection.query('SELECT id, username, role FROM users', (err, results) => {
        if (err) {
            console.error('Error fetching users:', err);
            return res.status(500).send('Error fetching users');
        }
        res.json(results);
    });
});



// API to add user
app.post('/add-user', (req, res) => {
    const { username, password } = req.body;

    // check if username existed
    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error checking user:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            return res.status(400).send('User already exists. Please choose another username.');
        }

        // hasing pass before saving into database
        bcrypt.hash(password, 10, (err, hash) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.status(500).send('Internal Server Error');
            }

            // add new use with default role is 'user'
            connection.query('INSERT INTO users (username, password, role) VALUES (?, ?, 0)', [username, hash], (err) => {
                if (err) {
                    console.error('Error inserting user:', err);
                    return res.status(500).send('Internal Server Error');
                }

                res.status(200).send('User added successfully');
            });
        });
    });
});



// API to delete user
app.delete('/delete-user/:id', (req, res) => {
    const userId = req.params.id;

    connection.query(
        'DELETE FROM users WHERE id = ?',
        [userId],
        (err, results) => {
            if (err) {
                console.error('Error deleting user:', err);
                return res.status(500).send('Error deleting user');
            }
            res.sendStatus(200);
        }
    );
});


// -----------------------------------------ELSE--------------------------------------------------------------------


// Other routes
app.get('/invoice.html', (req, res) => {
    createReadStream('invoice.html').pipe(res);
});
app.get('/style_login.css', (req, res) => {
    createReadStream('style_login.css').pipe(res);
});
app.get('/login_style.css', (req, res) => {
    createReadStream('./login_style.css').pipe(res);
});
app.get('/style_viewerpage.css', (req, res) => {
    createReadStream('./style_viewerpage.css').pipe(res);
});
app.get('/script_viewerpage.js', (req, res) => {
    createReadStream('./script_viewerpage.js').pipe(res);
});
app.get('/script_login.js', (req, res) => {
    createReadStream('./script_login.js').pipe(res);
});
app.get('/style_customer.css', (req, res) => {
    createReadStream('./style_customer.css').pipe(res);
});
app.get('/script_customer.js', (req, res) => {
    createReadStream('./script_customer.js').pipe(res);
});
app.get('/script_invoice.js', (req, res) => {
    createReadStream('./script_invoice.js').pipe(res);
});
app.get('/style_invoice.css', (req, res) => {
    createReadStream('./style_invoice.css').pipe(res);
});
app.get('/script_account.js', (req, res) => {
    createReadStream('./script_account.js').pipe(res);
});
app.get('/style_account.css', (req, res) => {
    createReadStream('./style_account.css').pipe(res);
});

// Load images
const assets = [
    'logo.png', 'user.png', 'cart.png', 'img_1.png', 'img_2.png',
    'img_3.png', 'to_bottom.png', 'product_1.png', 'product_2.png',
    'product_3.png', 'product_4.png', 'product_5.png', 'product_6.png',
    'prev.png', 'avatar_1.png', 'star.png', 'next.png', 'banner.png',
    'off.png'
];

// Create routes for each image in the list
assets.forEach(asset => {
    app.get(`/assets/${asset}`, (req, res) => {
        createReadStream(path.join(__dirname, 'assets', asset)).pipe(res);
    });
});

app.listen(4010, () => {
    console.log('Server running on http://localhost:4010');
});
